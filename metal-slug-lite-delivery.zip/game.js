const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const restartButton = document.getElementById("restartButton");

const VIEW_WIDTH = canvas.width;
const VIEW_HEIGHT = canvas.height;
const WORLD_WIDTH = 3400;
const GRAVITY = 1700;
const FLOOR_Y = 458;
const PLAYER_SPEED = 290;
const JUMP_SPEED = 650;
const BULLET_SPEED = 760;
const ENEMY_BULLET_SPEED = 320;
const GRENADE_SPEED_X = 320;
const GRENADE_SPEED_Y = 640;

const keys = new Set();

window.addEventListener("keydown", (event) => {
  const blockedKeys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "];
  if (blockedKeys.includes(event.key)) {
    event.preventDefault();
  }
  keys.add(event.key.toLowerCase());
});

window.addEventListener("keyup", (event) => {
  keys.delete(event.key.toLowerCase());
});

restartButton.addEventListener("click", () => {
  resetGame(state ? state.stageIndex : 0);
});

function rectsOverlap(a, b) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  );
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function centerOf(entity) {
  return {
    x: entity.x + entity.width / 2,
    y: entity.y + entity.height / 2
  };
}

const JUNGLE_PLATFORMS = [
  { x: 0, y: FLOOR_Y, width: WORLD_WIDTH, height: VIEW_HEIGHT - FLOOR_Y },
  { x: 320, y: 360, width: 150, height: 20 },
  { x: 720, y: 320, width: 240, height: 20 },
  { x: 1080, y: 380, width: 180, height: 20 },
  { x: 1500, y: 340, width: 180, height: 20 },
  { x: 1920, y: 300, width: 220, height: 20 },
  { x: 2310, y: 365, width: 210, height: 20 },
  { x: 2700, y: 335, width: 160, height: 20 }
];

const SNOW_PLATFORMS = [
  { x: 0, y: FLOOR_Y, width: WORLD_WIDTH, height: VIEW_HEIGHT - FLOOR_Y },
  { x: 300, y: 380, width: 170, height: 20 },
  { x: 680, y: 332, width: 210, height: 20 },
  { x: 1050, y: 292, width: 180, height: 20 },
  { x: 1450, y: 360, width: 230, height: 20 },
  { x: 1870, y: 308, width: 210, height: 20 },
  { x: 2260, y: 350, width: 220, height: 20 },
  { x: 2700, y: 300, width: 190, height: 20 }
];

const DESERT_PLATFORMS = [
  { x: 0, y: FLOOR_Y, width: WORLD_WIDTH, height: VIEW_HEIGHT - FLOOR_Y },
  { x: 360, y: 388, width: 180, height: 20 },
  { x: 760, y: 338, width: 210, height: 20 },
  { x: 1120, y: 300, width: 190, height: 20 },
  { x: 1520, y: 356, width: 240, height: 20 },
  { x: 1960, y: 316, width: 230, height: 20 },
  { x: 2380, y: 276, width: 210, height: 20 },
  { x: 2820, y: 332, width: 210, height: 20 }
];

const CITY_PLATFORMS = [
  { x: 0, y: FLOOR_Y, width: WORLD_WIDTH, height: VIEW_HEIGHT - FLOOR_Y },
  { x: 340, y: 372, width: 180, height: 20 },
  { x: 720, y: 318, width: 220, height: 20 },
  { x: 1100, y: 278, width: 190, height: 20 },
  { x: 1510, y: 344, width: 240, height: 20 },
  { x: 1960, y: 296, width: 220, height: 20 },
  { x: 2380, y: 258, width: 230, height: 20 },
  { x: 2840, y: 324, width: 210, height: 20 }
];

const GRASSLAND_PLATFORMS = [
  { x: 0, y: FLOOR_Y, width: WORLD_WIDTH, height: VIEW_HEIGHT - FLOOR_Y },
  { x: 330, y: 386, width: 190, height: 20 },
  { x: 720, y: 336, width: 220, height: 20 },
  { x: 1110, y: 294, width: 190, height: 20 },
  { x: 1520, y: 350, width: 240, height: 20 },
  { x: 1960, y: 306, width: 230, height: 20 },
  { x: 2390, y: 266, width: 220, height: 20 },
  { x: 2840, y: 324, width: 220, height: 20 }
];

const HARBOR_PLATFORMS = [
  { x: 0, y: FLOOR_Y, width: WORLD_WIDTH, height: VIEW_HEIGHT - FLOOR_Y },
  { x: 340, y: 392, width: 200, height: 20 },
  { x: 760, y: 344, width: 220, height: 20 },
  { x: 1150, y: 304, width: 200, height: 20 },
  { x: 1560, y: 360, width: 250, height: 20 },
  { x: 2020, y: 316, width: 240, height: 20 },
  { x: 2450, y: 276, width: 230, height: 20 },
  { x: 2880, y: 334, width: 220, height: 20 }
];

const TOTAL_STAGES = 6;
let platforms = JUNGLE_PLATFORMS;

let state;
let lastTime = 0;

function getTerrainLabel(theme) {
  if (theme === "snow") {
    return "冰面";
  }
  if (theme === "desert") {
    return "沙地";
  }
  if (theme === "city") {
    return "街区";
  }
  if (theme === "grassland") {
    return "草地";
  }
  if (theme === "harbor") {
    return "码头";
  }
  return "土路";
}

function getStageLoadingText(theme) {
  if (theme === "snow") {
    return "冰雪战区正在装填中...";
  }
  if (theme === "desert") {
    return "沙漠战区正在装填中...";
  }
  if (theme === "city") {
    return "都市战区正在装填中...";
  }
  if (theme === "grassland") {
    return "草原战区正在装填中...";
  }
  if (theme === "harbor") {
    return "海港战区正在装填中...";
  }
  return "下一战区正在装填中...";
}

function createPlayer() {
  return {
    x: 90,
    y: 250,
    width: 38,
    height: 62,
    vx: 0,
    vy: 0,
    facing: 1,
    hp: 5,
    grenades: 8,
    weapon: "normal",
    weaponAmmo: Infinity,
    invulnerability: 0,
    onGround: false,
    crouching: false,
    shootCooldown: 0,
    grenadeCooldown: 0,
    stepTimer: 0,
    vehicleCooldown: 0,
    hurtTimer: 0,
    snowTrackCooldown: 0
  };
}

function createEnemy(config) {
  return {
    type: config.type,
    x: config.x,
    y: config.y,
    width: config.width || 38,
    height: config.height || 52,
    hp: config.hp || 2,
    maxHp: config.hp || 2,
    patrolMin: config.patrolMin || config.x - 80,
    patrolMax: config.patrolMax || config.x + 80,
    speed: config.speed || 60,
    direction: -1,
    vx: 0,
    vy: 0,
    shootCooldown: config.shootCooldown || 1.4,
    shootInterval: config.shootInterval || 1.4,
    stationary: Boolean(config.stationary),
    color: config.color || "#c94d43",
    bulletColor: config.bulletColor || "#ffd966",
    projectileSpeed: config.projectileSpeed || ENEMY_BULLET_SPEED,
    aimRange: config.aimRange || 520,
    damage: config.damage || 1,
    scoreValue: config.scoreValue || 300,
    baseY: config.baseY ?? config.y,
    floatAmplitude: config.floatAmplitude || 18,
    phaseOffset: config.phaseOffset || 0,
    burstCooldown: 0,
    hurtTimer: 0
  };
}

function createBoss(config = {}) {
  return {
    type: "boss",
    x: config.x ?? 3180,
    y: config.y ?? 280,
    width: config.width ?? 140,
    height: config.height ?? 130,
    hp: config.hp ?? 24,
    maxHp: config.hp ?? 24,
    shootCooldown: config.shootCooldown ?? 0.8,
    shootInterval: config.shootInterval ?? 0.8,
    projectileSpeed: config.projectileSpeed ?? 380,
    aimRange: config.aimRange ?? 920,
    damage: config.damage ?? 1,
    direction: -1,
    scoreValue: config.scoreValue ?? 3000,
    flashTimer: 0,
    pulseTimer: 0,
    hurtTimer: 0,
    barrageCooldown: 1.8,
    stormCooldown: config.stormCooldown ?? 2.8,
    wallCooldown: config.wallCooldown ?? 4.2,
    phase: 1,
    name: config.name || "重炮台",
    bodyColor: config.bodyColor || "#485262",
    topColor: config.topColor || "#687487",
    detailColor: config.detailColor || "#8593a6",
    gunColor: config.gunColor || "#ff8a4d",
    eyeColor: config.eyeColor || "#ffcf82",
    glowColor: config.glowColor || "#ff9b45"
  };
}

function createHostage(x) {
  return {
    x,
    y: FLOOR_Y - 54,
    width: 24,
    height: 54,
    rescued: false,
    rewardDropped: false,
    timer: 0
  };
}

function createPickup(x, y, type) {
  return {
    x,
    y,
    width: 24,
    height: 24,
    type,
    vy: -180,
    ttl: 14
  };
}

function createWeaponCrate(x, y, type) {
  return {
    x,
    y,
    width: 30,
    height: 26,
    type,
    hp: 1,
    opened: false
  };
}

function createVehicle(x) {
  return {
    x,
    y: FLOOR_Y - 34,
    width: 74,
    height: 34,
    hp: 10,
    maxHp: 10,
    vx: 0,
    vy: 0,
    occupied: false,
    destroyed: false,
    invulnerability: 0,
    cannonCooldown: 0,
    flashTimer: 0,
    snowTrackCooldown: 0
  };
}

function createFragment(x, y, color) {
  return {
    x,
    y,
    width: 8 + Math.random() * 6,
    height: 5 + Math.random() * 5,
    vx: (Math.random() - 0.5) * 280,
    vy: -120 - Math.random() * 220,
    color,
    ttl: 0.9 + Math.random() * 0.45,
    maxTtl: 1.2
  };
}

function createTurret(x, y) {
  return {
    type: "turret",
    x,
    y,
    width: 58,
    height: 66,
    hp: 10,
    maxHp: 10,
    shootCooldown: 1,
    shootInterval: 1,
    projectileSpeed: 330,
    aimRange: 560,
    damage: 1,
    direction: -1,
    scoreValue: 1200,
    flashTimer: 0,
    hurtTimer: 0
  };
}

function createStageEvent(x, kind, notice, color = "#ffe08a", targetOffset = 120) {
  return {
    x,
    kind,
    notice,
    color,
    targetOffset
  };
}

function getStageData(stageIndex) {
  if (stageIndex === 5) {
    return {
      stageIndex: 5,
      theme: "harbor",
      missionLabel: "MISSION 6",
      subtitle: "HARBOR HAVOC",
      tip: "突入海港封锁线，救出船员，击沉钢牙战舰完成第六段闭环",
      platforms: HARBOR_PLATFORMS,
      enemies: [
        createEnemy({ type: "patrol", x: 500, y: 418, patrolMin: 430, patrolMax: 680, hp: 3, speed: 76, color: "#4f88a0", bulletColor: "#bcecff", scoreValue: 460 }),
        createEnemy({ type: "sniper", x: 900, y: 292, stationary: true, hp: 2, shootInterval: 1.36, color: "#6ba1ba", bulletColor: "#ddfbff", scoreValue: 560 }),
        createEnemy({ type: "patrol", x: 1270, y: 252, patrolMin: 1180, patrolMax: 1380, hp: 3, speed: 84, color: "#4f93b0", scoreValue: 580 }),
        createEnemy({ type: "mech", x: 1760, y: 386, width: 94, height: 74, hp: 17, stationary: true, shootInterval: 0.92, color: "#496b76", projectileSpeed: 360, aimRange: 720, scoreValue: 2100, damage: 1 }),
        createEnemy({ type: "sniper", x: 2130, y: 264, stationary: true, hp: 3, shootInterval: 1.15, color: "#7eb7cf", bulletColor: "#efffff", scoreValue: 580 }),
        createEnemy({ type: "patrol", x: 2530, y: 222, patrolMin: 2450, patrolMax: 2650, hp: 4, speed: 86, color: "#45849b", scoreValue: 620 }),
        createEnemy({ type: "patrol", x: 2960, y: 282, patrolMin: 2870, patrolMax: 3090, hp: 4, speed: 92, color: "#5aa0bb", scoreValue: 680 }),
        createEnemy({ type: "patrol", x: 3120, y: 406, patrolMin: 3030, patrolMax: 3240, hp: 5, speed: 94, color: "#71b5cc", scoreValue: 740 })
      ],
      hostages: [createHostage(1420), createHostage(2640)],
      crates: [
        createWeaponCrate(980, FLOOR_Y - 26, "hmg"),
        createWeaponCrate(2160, FLOOR_Y - 26, "shotgun"),
        createWeaponCrate(3040, FLOOR_Y - 26, "flame")
      ],
      events: [
        createStageEvent(1320, "depthCharge", "港区投雷", "#c7fbff", 150),
        createStageEvent(2360, "steamColumn", "蒸汽管线泄压", "#d9fbff", 110)
      ],
      vehicle: createVehicle(1680),
      turrets: [createTurret(2300, FLOOR_Y - 66), createTurret(3020, FLOOR_Y - 66)],
      boss: createBoss({
        x: 3140,
        y: 242,
        hp: 44,
        shootInterval: 0.58,
        projectileSpeed: 455,
        scoreValue: 9200,
        name: "钢牙战舰",
        bodyColor: "#416071",
        topColor: "#6790a5",
        detailColor: "#c2e6f1",
        gunColor: "#8ce7ff",
        eyeColor: "#ffffff",
        glowColor: "#b9f7ff"
      })
    };
  }

  if (stageIndex === 4) {
    return {
      stageIndex: 4,
      theme: "grassland",
      missionLabel: "MISSION 5",
      subtitle: "STEPPE THUNDER",
      tip: "冲破草原防线，救出向导，击坠雷霆战禽完成第五段闭环",
      platforms: GRASSLAND_PLATFORMS,
      enemies: [
        createEnemy({ type: "patrol", x: 470, y: 412, patrolMin: 400, patrolMax: 650, hp: 3, speed: 74, color: "#6f9448", bulletColor: "#dff5af", scoreValue: 420 }),
        createEnemy({ type: "sniper", x: 860, y: 284, stationary: true, hp: 2, shootInterval: 1.42, color: "#88ab5f", bulletColor: "#efffca", scoreValue: 520 }),
        createEnemy({ type: "glider", x: 1060, y: 188, baseY: 188, patrolMin: 980, patrolMax: 1380, width: 52, height: 34, hp: 3, speed: 104, shootInterval: 1.5, aimRange: 560, color: "#7fa75a", bulletColor: "#f5ffd2", floatAmplitude: 16, scoreValue: 620 }),
        createEnemy({ type: "patrol", x: 1230, y: 242, patrolMin: 1140, patrolMax: 1340, hp: 3, speed: 82, color: "#7da651", scoreValue: 540 }),
        createEnemy({ type: "mech", x: 1710, y: 386, width: 92, height: 74, hp: 16, stationary: true, shootInterval: 0.95, color: "#64754e", projectileSpeed: 350, aimRange: 700, scoreValue: 1950, damage: 1 }),
        createEnemy({ type: "sniper", x: 2080, y: 254, stationary: true, hp: 3, shootInterval: 1.2, color: "#96b76b", bulletColor: "#f2ffdd", scoreValue: 560 }),
        createEnemy({ type: "glider", x: 2550, y: 170, baseY: 170, patrolMin: 2460, patrolMax: 2870, width: 52, height: 34, hp: 3, speed: 112, shootInterval: 1.35, aimRange: 580, color: "#8fb566", bulletColor: "#f5ffd2", floatAmplitude: 20, phaseOffset: 1.4, scoreValue: 680 }),
        createEnemy({ type: "patrol", x: 2480, y: 210, patrolMin: 2400, patrolMax: 2600, hp: 4, speed: 84, color: "#73994a", scoreValue: 600 }),
        createEnemy({ type: "patrol", x: 2910, y: 272, patrolMin: 2820, patrolMax: 3040, hp: 4, speed: 90, color: "#8eb85c", scoreValue: 640 }),
        createEnemy({ type: "patrol", x: 3100, y: 406, patrolMin: 3010, patrolMax: 3220, hp: 4, speed: 92, color: "#9cc765", scoreValue: 700 })
      ],
      hostages: [createHostage(1380), createHostage(2600)],
      crates: [
        createWeaponCrate(980, FLOOR_Y - 26, "hmg"),
        createWeaponCrate(2140, FLOOR_Y - 26, "shotgun"),
        createWeaponCrate(3010, FLOOR_Y - 26, "flame")
      ],
      events: [
        createStageEvent(1260, "windBlade", "侧风切割来袭", "#efffb2", 140),
        createStageEvent(1660, "gliderAmbush", "滑翔敌兵俯冲", "#efffb2", 160),
        createStageEvent(2320, "thornWall", "灌木荆墙封路", "#d6ff8a", 100)
      ],
      vehicle: createVehicle(1640),
      turrets: [createTurret(2260, FLOOR_Y - 66), createTurret(2980, FLOOR_Y - 66)],
      boss: createBoss({
        x: 3145,
        y: 248,
        hp: 40,
        shootInterval: 0.62,
        projectileSpeed: 440,
        scoreValue: 7800,
        name: "雷霆战禽",
        bodyColor: "#5b6f44",
        topColor: "#86a85b",
        detailColor: "#d6ecad",
        gunColor: "#d6ff8a",
        eyeColor: "#ffffff",
        glowColor: "#efffb2"
      })
    };
  }

  if (stageIndex === 3) {
    return {
      stageIndex: 3,
      theme: "city",
      missionLabel: "MISSION 4",
      subtitle: "CITY SIEGE",
      tip: "杀入都市封锁线，救出通讯员，摧毁机甲中枢完成第四段闭环",
      platforms: CITY_PLATFORMS,
      enemies: [
        createEnemy({ type: "patrol", x: 480, y: 398, patrolMin: 410, patrolMax: 650, hp: 3, speed: 72, color: "#6f869e", bulletColor: "#c4efff", scoreValue: 380 }),
        createEnemy({ type: "sniper", x: 860, y: 266, stationary: true, hp: 2, shootInterval: 1.4, color: "#889db5", bulletColor: "#d4fbff", scoreValue: 500 }),
        createEnemy({ type: "patrol", x: 1220, y: 224, patrolMin: 1120, patrolMax: 1320, hp: 3, speed: 82, color: "#7a92ab", scoreValue: 520 }),
        createEnemy({ type: "mech", x: 1700, y: 386, width: 92, height: 74, hp: 15, stationary: true, shootInterval: 0.98, color: "#657485", projectileSpeed: 345, aimRange: 700, scoreValue: 1850, damage: 1 }),
        createEnemy({ type: "sniper", x: 2060, y: 244, stationary: true, hp: 3, shootInterval: 1.25, color: "#9ab0c6", bulletColor: "#e5feff", scoreValue: 540 }),
        createEnemy({ type: "patrol", x: 2470, y: 202, patrolMin: 2390, patrolMax: 2590, hp: 4, speed: 84, color: "#7d8fa4", scoreValue: 560 }),
        createEnemy({ type: "patrol", x: 2890, y: 272, patrolMin: 2810, patrolMax: 3020, hp: 4, speed: 88, color: "#89a1ba", scoreValue: 620 }),
        createEnemy({ type: "patrol", x: 3095, y: 406, patrolMin: 3005, patrolMax: 3210, hp: 4, speed: 90, color: "#96adc4", scoreValue: 660 })
      ],
      hostages: [createHostage(1400), createHostage(2620)],
      crates: [
        createWeaponCrate(980, FLOOR_Y - 26, "hmg"),
        createWeaponCrate(2140, FLOOR_Y - 26, "shotgun"),
        createWeaponCrate(3000, FLOOR_Y - 26, "flame")
      ],
      events: [
        createStageEvent(1360, "missileRain", "楼顶导弹齐射", "#c7fbff", 150),
        createStageEvent(2400, "laserFence", "能量栅栏启动", "#b8f7ff", 110)
      ],
      vehicle: createVehicle(1620),
      turrets: [createTurret(2260, FLOOR_Y - 66), createTurret(2980, FLOOR_Y - 66)],
      boss: createBoss({
        x: 3140,
        y: 252,
        hp: 36,
        shootInterval: 0.66,
        projectileSpeed: 430,
        scoreValue: 6500,
        name: "机甲中枢",
        bodyColor: "#4f5d70",
        topColor: "#7f93ad",
        detailColor: "#c7d9ef",
        gunColor: "#8be6ff",
        eyeColor: "#ffffff",
        glowColor: "#9de7ff"
      })
    };
  }

  if (stageIndex === 2) {
    return {
      stageIndex: 2,
      theme: "desert",
      missionLabel: "MISSION 3",
      subtitle: "DESERT RAID",
      tip: "冲过沙丘遗迹，救出侦察兵，击毁沙暴母舰完成第三段闭环",
      platforms: DESERT_PLATFORMS,
      enemies: [
        createEnemy({ type: "patrol", x: 500, y: 414, patrolMin: 420, patrolMax: 700, hp: 3, speed: 68, color: "#b06e3d", bulletColor: "#ffd38a", scoreValue: 340 }),
        createEnemy({ type: "sniper", x: 890, y: 286, stationary: true, hp: 2, shootInterval: 1.55, color: "#b7854f", bulletColor: "#ffe6b4", scoreValue: 460 }),
        createEnemy({ type: "patrol", x: 1250, y: 246, patrolMin: 1140, patrolMax: 1360, hp: 3, speed: 78, color: "#c17b46" }),
        createEnemy({ type: "mech", x: 1730, y: 386, width: 90, height: 72, hp: 14, stationary: true, shootInterval: 1.05, color: "#8a7257", projectileSpeed: 330, aimRange: 660, scoreValue: 1650, damage: 1 }),
        createEnemy({ type: "sniper", x: 2070, y: 264, stationary: true, hp: 2, shootInterval: 1.35, color: "#c49359", bulletColor: "#ffe5b1", scoreValue: 500 }),
        createEnemy({ type: "patrol", x: 2480, y: 222, patrolMin: 2400, patrolMax: 2600, hp: 3, speed: 82, color: "#b36f34", scoreValue: 520 }),
        createEnemy({ type: "patrol", x: 2910, y: 280, patrolMin: 2830, patrolMax: 3030, hp: 4, speed: 84, color: "#cc8748", scoreValue: 560 }),
        createEnemy({ type: "patrol", x: 3080, y: 406, patrolMin: 3000, patrolMax: 3200, hp: 4, speed: 88, color: "#d98a4e", scoreValue: 600 })
      ],
      hostages: [createHostage(1360), createHostage(2580)],
      crates: [
        createWeaponCrate(980, FLOOR_Y - 26, "shotgun"),
        createWeaponCrate(2140, FLOOR_Y - 26, "hmg"),
        createWeaponCrate(3010, FLOOR_Y - 26, "flame")
      ],
      events: [
        createStageEvent(1240, "sandBurst", "遗迹沙暴来袭", "#ffe1a8", 140),
        createStageEvent(1680, "ruinAmbush", "遗迹埋伏现身", "#ffd894", 120),
        createStageEvent(2300, "sandPillar", "断墙突刺", "#ffd894", 100)
      ],
      vehicle: createVehicle(1660),
      turrets: [createTurret(2240, FLOOR_Y - 66), createTurret(2960, FLOOR_Y - 66)],
      boss: createBoss({
        x: 3150,
        y: 262,
        hp: 32,
        shootInterval: 0.72,
        projectileSpeed: 415,
        scoreValue: 5200,
        name: "沙暴母舰",
        bodyColor: "#816645",
        topColor: "#b08a58",
        detailColor: "#e3c58d",
        gunColor: "#ffbf66",
        eyeColor: "#fff0c4",
        glowColor: "#ffd287"
      })
    };
  }

  if (stageIndex === 1) {
    return {
      stageIndex: 1,
      theme: "snow",
      missionLabel: "MISSION 2",
      subtitle: "FROZEN FRONT",
      tip: "踩着冰平台推进，救出工程师，打爆雪域要塞完成第二段闭环",
      platforms: SNOW_PLATFORMS,
      enemies: [
        createEnemy({ type: "patrol", x: 460, y: 406, patrolMin: 390, patrolMax: 620, hp: 2, color: "#6f8fc5", bulletColor: "#d9f3ff" }),
        createEnemy({ type: "sniper", x: 810, y: 280, stationary: true, hp: 2, shootInterval: 1.7, color: "#7ea6de", bulletColor: "#d9f3ff", scoreValue: 420 }),
        createEnemy({ type: "patrol", x: 1180, y: 238, patrolMin: 1080, patrolMax: 1280, hp: 3, speed: 74, color: "#8aa6d8" }),
        createEnemy({ type: "mech", x: 1680, y: 386, width: 86, height: 72, hp: 13, stationary: true, shootInterval: 1.1, color: "#8b96a4", projectileSpeed: 320, aimRange: 640, scoreValue: 1550, damage: 1 }),
        createEnemy({ type: "sniper", x: 2010, y: 256, stationary: true, hp: 2, shootInterval: 1.45, color: "#9db8ea", bulletColor: "#d9f3ff", scoreValue: 460 }),
        createEnemy({ type: "patrol", x: 2360, y: 296, patrolMin: 2280, patrolMax: 2500, hp: 3, speed: 80, color: "#7f99c9" }),
        createEnemy({ type: "patrol", x: 2830, y: 248, patrolMin: 2740, patrolMax: 2940, hp: 3, speed: 82, color: "#8ca7d8", scoreValue: 520 })
      ],
      hostages: [createHostage(1320), createHostage(2520)],
      crates: [
        createWeaponCrate(910, FLOOR_Y - 26, "shotgun"),
        createWeaponCrate(2140, FLOOR_Y - 26, "hmg"),
        createWeaponCrate(2860, FLOOR_Y - 26, "flame")
      ],
      vehicle: createVehicle(1540),
      turrets: [createTurret(2190, FLOOR_Y - 66), createTurret(2920, FLOOR_Y - 66)],
      boss: createBoss({
        x: 3150,
        y: 270,
        hp: 28,
        shootInterval: 0.75,
        projectileSpeed: 400,
        scoreValue: 4200,
        name: "雪域要塞",
        bodyColor: "#66788f",
        topColor: "#91a7c1",
        detailColor: "#c8d8ea",
        gunColor: "#8be1ff",
        eyeColor: "#ffffff",
        glowColor: "#9fe7ff"
      })
    };
  }

  return {
    stageIndex: 0,
    theme: "jungle",
    missionLabel: "MISSION 1",
    subtitle: "JUNGLE STRIKE",
    tip: "向右突进，打爆武器箱，乘上小坦克，突破前线火力",
    platforms: JUNGLE_PLATFORMS,
    enemies: [
      createEnemy({ type: "patrol", x: 540, y: 406, patrolMin: 500, patrolMax: 710, hp: 2 }),
      createEnemy({ type: "sniper", x: 860, y: 268, stationary: true, hp: 2, shootInterval: 1.8, color: "#7b3fc4", scoreValue: 400 }),
      createEnemy({ type: "patrol", x: 1210, y: 426, patrolMin: 1120, patrolMax: 1350, hp: 3, speed: 72 }),
      createEnemy({ type: "patrol", x: 1580, y: 286, patrolMin: 1530, patrolMax: 1710, hp: 2, speed: 58 }),
      createEnemy({ type: "mech", x: 1880, y: 386, width: 86, height: 72, hp: 12, stationary: true, shootInterval: 1.2, color: "#6f7a86", projectileSpeed: 300, aimRange: 620, scoreValue: 1400, damage: 1 }),
      createEnemy({ type: "sniper", x: 2030, y: 248, stationary: true, hp: 2, shootInterval: 1.5, color: "#8c4c2f", scoreValue: 450 }),
      createEnemy({ type: "patrol", x: 2400, y: 311, patrolMin: 2320, patrolMax: 2510, hp: 3, speed: 78 }),
      createEnemy({ type: "patrol", x: 2760, y: 281, patrolMin: 2680, patrolMax: 2850, hp: 2, speed: 66 }),
      createEnemy({ type: "patrol", x: 2950, y: 406, patrolMin: 2890, patrolMax: 3070, hp: 3, speed: 86, color: "#db5548", scoreValue: 500 })
    ],
    hostages: [createHostage(1330), createHostage(2460)],
    crates: [
      createWeaponCrate(980, FLOOR_Y - 26, "hmg"),
      createWeaponCrate(2140, FLOOR_Y - 26, "shotgun"),
      createWeaponCrate(2580, FLOOR_Y - 26, "flame")
    ],
    vehicle: createVehicle(1760),
    turrets: [createTurret(2245, FLOOR_Y - 66), createTurret(2870, FLOOR_Y - 66)],
    boss: createBoss()
  };
}

function resetGame(stageIndex = 0, carry = {}) {
  const clampedStageIndex = clamp(stageIndex, 0, TOTAL_STAGES - 1);
  const stage = getStageData(clampedStageIndex);
  const nextStagePreview = clampedStageIndex < TOTAL_STAGES - 1 ? getStageData(clampedStageIndex + 1) : null;
  const player = createPlayer();
  if (carry.playerStats) {
    player.hp = Math.max(3, carry.playerStats.hp ?? player.hp);
    player.grenades = Math.max(4, carry.playerStats.grenades ?? player.grenades);
    if (carry.playerStats.weapon && carry.playerStats.weapon !== "normal" && carry.playerStats.weaponAmmo > 0) {
      player.weapon = carry.playerStats.weapon;
      player.weaponAmmo = carry.playerStats.weaponAmmo;
    }
  }
  platforms = stage.platforms;
  state = {
    stageIndex: clampedStageIndex,
    stageTheme: stage.theme,
    missionLabel: stage.missionLabel,
    missionSubtitle: stage.subtitle,
    stageTip: stage.tip,
    stageEvents: (stage.events || []).map((event) => ({ ...event, triggered: false })),
    stageClear: false,
    nextStagePending: clampedStageIndex < TOTAL_STAGES - 1,
    nextMissionLabel: nextStagePreview ? nextStagePreview.missionLabel : "",
    nextMissionSubtitle: nextStagePreview ? nextStagePreview.subtitle : "",
    nextStageTheme: nextStagePreview ? nextStagePreview.theme : "",
    player,
    bullets: [],
    grenades: [],
    hazards: [],
    enemyBullets: [],
    enemies: stage.enemies,
    hostages: stage.hostages,
    crates: stage.crates,
    pickups: [],
    vehicle: stage.vehicle,
    turrets: stage.turrets,
    boss: stage.boss,
    effects: [],
    fragments: [],
    floatingTexts: [],
    snowMarks: [],
    cameraX: 0,
    victory: false,
    gameOver: false,
    bossAwake: false,
    bossBannerPlayed: false,
    interceptBannerTimer: 0,
    messageTimer: 0,
    stageBannerTimer: 3.2,
    warningTimer: 0,
    eventNoticeText: "",
    eventNoticeColor: "#fff3a8",
    eventNoticeTimer: 0,
    shakeTime: 0,
    shakePower: 0,
    score: carry.score || 0
  };
}

function spawnEffect(x, y, color, radius = 10, ttl = 0.24, growth = 90) {
  state.effects.push({
    x,
    y,
    color,
    radius,
    ttl,
    maxTtl: ttl,
    growth
  });
}

function spawnFloatingText(text, x, y, color = "#fff3a8", size = 18) {
  state.floatingTexts.push({
    text,
    x,
    y,
    vy: -28,
    ttl: 1.2,
    maxTtl: 1.2,
    color,
    size
  });
}

function announceStageEvent(text, color = "#fff3a8") {
  state.eventNoticeText = text;
  state.eventNoticeColor = color;
  state.eventNoticeTimer = 1.5;
}

function spawnSnowTrack(x, width, strength = 1) {
  state.snowMarks.push({
    x,
    y: FLOOR_Y - 5,
    width,
    ttl: 0.75 + strength * 0.25,
    maxTtl: 1.1 + strength * 0.25
  });
}

function addShake(power, time) {
  state.shakePower = Math.max(state.shakePower, power);
  state.shakeTime = Math.max(state.shakeTime, time);
}

function grantPickup(type) {
  const player = state.player;
  if (type === "grenade") {
    player.grenades += 4;
    spawnFloatingText("+4 手雷", player.x + 10, player.y - 12, "#ffd25f");
  } else if (type === "medkit") {
    player.hp = Math.min(5, player.hp + 1);
    spawnFloatingText("生命 +1", player.x + 10, player.y - 12, "#8cffaf");
  } else if (type === "hmg") {
    player.weapon = "heavy";
    player.weaponAmmo = 120;
    spawnFloatingText("HEAVY MACHINE GUN!", player.x - 24, player.y - 18, "#ffe08a", 18);
  } else if (type === "shotgun") {
    player.weapon = "shotgun";
    player.weaponAmmo = 24;
    spawnFloatingText("SHOTGUN!", player.x - 4, player.y - 18, "#ffd25f", 18);
  } else if (type === "flame") {
    player.weapon = "flame";
    player.weaponAmmo = 80;
    spawnFloatingText("FLAME SHOT!", player.x - 10, player.y - 18, "#ff9f59", 18);
  } else if (type === "medal") {
    state.score += 250;
    spawnFloatingText("+250", player.x + 8, player.y - 14, "#ffe08a", 16);
  }
}

function breakCrate(crate) {
  if (crate.opened) {
    return;
  }
  crate.opened = true;
  state.pickups.push(createPickup(crate.x + 4, crate.y - 8, crate.type));
  spawnEffect(crate.x + crate.width / 2, crate.y + crate.height / 2, "#d9b37a", 18, 0.24, 120);
  const label = crate.type === "hmg" ? "H" : crate.type === "shotgun" ? "S" : crate.type === "flame" ? "F" : "SUPPLY";
  spawnFloatingText(label, crate.x - 4, crate.y - 14, "#fff1a6", 18);
  spawnEffect(crate.x + crate.width / 2, crate.y + 6, "#fff0b5", 12, 0.16, 90);
}

function maybeDropEnemyLoot(target) {
  if (target.type === "turret") {
    const dropType = Math.random() > 0.5 ? "grenade" : "medkit";
    state.pickups.push(createPickup(target.x + target.width / 2, target.y, dropType));
    spawnFloatingText("SUPPLY", target.x - 4, target.y - 18, "#fff1a6", 16);
    return;
  }

  if (target.type === "boss" || target.type === "mech") {
    const dropType = Math.random() > 0.5 ? "grenade" : "medkit";
    state.pickups.push(createPickup(target.x + target.width / 2, target.y, dropType));
    return;
  }

  if (Math.random() < 0.26) {
    state.pickups.push(createPickup(target.x + target.width / 2, target.y, "medal"));
  }
}

function destroyEnemy(target) {
  const { x, y } = centerOf(target);
  const fragmentCount = target.type === "boss" ? 18 : target.type === "mech" ? 12 : target.type === "turret" ? 10 : 6;
  const fragmentColors =
    target.type === "mech"
      ? ["#788391", "#485262", "#ffb84d"]
      : target.type === "turret"
        ? ["#6f747c", "#a2a7ae", "#ff9b45"]
        : ["#ff8b6b", "#d46a4d", "#8b4b3b"];
  for (let i = 0; i < 4; i += 1) {
    spawnEffect(x + (Math.random() - 0.5) * 18, y + (Math.random() - 0.5) * 18, i % 2 === 0 ? "#ff8b6b" : "#ffe08a", 20 + i * 4, 0.35, 120);
  }
  for (let i = 0; i < fragmentCount; i += 1) {
    state.fragments.push(createFragment(x, y, fragmentColors[i % fragmentColors.length]));
  }

  state.score += target.scoreValue || 200;
  addShake(target.type === "boss" ? 12 : 6, target.type === "boss" ? 0.4 : 0.18);
  spawnFloatingText(`+${target.scoreValue || 200}`, x - 14, y - 18, "#ffd25f");
  maybeDropEnemyLoot(target);

  if (target.type === "boss") {
    state.messageTimer = 0;
    state.warningTimer = 0;
    if (state.stageIndex < TOTAL_STAGES - 1) {
      state.stageClear = true;
      spawnFloatingText(`${state.missionLabel} CLEAR`, x - 82, y - 46, "#ffdf7a", 24);
    } else {
      state.victory = true;
      spawnFloatingText("BOSS DOWN!", x - 46, y - 46, "#ffdf7a", 26);
    }
  } else if (target.type === "turret") {
    spawnFloatingText("TURRET DOWN!", x - 58, y - 30, "#ffd25f", 18);
  }
}

function damageEnemy(target, amount, hitX, hitY) {
  if (target.hp <= 0) {
    return;
  }
  target.hp -= amount;
  target.hurtTimer = target.type === "boss" ? 0.2 : 0.14;

  // 多层命中特效
  const isBig = target.type === "boss" || target.type === "mech" || target.type === "turret";
  // 中心闪光
  spawnEffect(hitX, hitY, "#ffffff", isBig ? 16 : 10, 0.08, 60);
  // 火花扩散
  spawnEffect(hitX, hitY, "#ffeb3b", isBig ? 22 : 14, 0.15, 100);
  // 橙色余烬
  spawnEffect(hitX, hitY, "#ff9800", isBig ? 18 : 12, 0.22, 70);
  // 红色烟雾
  if (isBig) {
    spawnEffect(hitX + (Math.random() - 0.5) * 10, hitY + (Math.random() - 0.5) * 10, "#ff5722", 14, 0.35, 40);
  }

  // 伤害数字浮动
  if (Math.random() < 0.5) {
    spawnFloatingText("-" + amount, hitX, hitY - 8, "#ffcc80", 14);
  }

  // 命中闪光提示（大型敌人）
  if (isBig && Math.random() < 0.3) {
    spawnFloatingText("HIT!", hitX + 16, hitY - 20, "#fff59d", 12);
  }

  if (target.hp <= 0) {
    destroyEnemy(target);
  }
}

function updateTurrets(dt, playerCenter) {
  for (const turret of state.turrets) {
    turret.flashTimer = Math.max(0, turret.flashTimer - dt);
    turret.hurtTimer = Math.max(0, turret.hurtTimer - dt);
    if (turret.hp <= 0) {
      continue;
    }

    if (rectsOverlap(state.player, turret)) {
      damagePlayer(1);
    }

    const turretCenter = centerOf(turret);
    const dx = playerCenter.x - turretCenter.x;
    const dy = playerCenter.y - turretCenter.y;
    const visibleWindow = turret.x > state.cameraX - 40 && turret.x < state.cameraX + VIEW_WIDTH + 80;
    const engaged = visibleWindow && Math.abs(dx) < turret.aimRange && Math.abs(dy) < 180;
    if (!engaged) {
      continue;
    }

    turret.direction = dx >= 0 ? 1 : -1;
    turret.shootCooldown -= dt;
    if (turret.shootCooldown <= 0) {
      fireEnemyBullet(turret, playerCenter.x, playerCenter.y - 10);
      turret.shootCooldown = turret.shootInterval;
      turret.flashTimer = 0.1;
      spawnEffect(turret.x + (turret.direction > 0 ? turret.width : 0), turret.y + 24, "#ffb84d", 10, 0.12, 80);
    }
  }
}

function explodeAt(x, y, radius, damage) {
  // 爆炸核心 - 白色闪光
  spawnEffect(x, y, "#ffffff", radius * 0.3, 0.08, radius * 2);
  // 内层 - 亮黄
  spawnEffect(x, y, "#fff176", radius * 0.5, 0.15, radius * 1.6);
  // 中层 - 橙黄
  spawnEffect(x, y, "#ffd54f", radius * 0.7, 0.22, radius * 1.3);
  // 外层 - 橙红
  spawnEffect(x, y, "#ff8a65", radius * 0.9, 0.28, radius * 1.0);
  // 最外层 - 深红烟雾
  spawnEffect(x, y, "#d84315", radius * 1.1, 0.4, radius * 0.6);
  // 冲击波环
  spawnEffect(x, y, "#ffeb3b", radius * 0.4, 0.12, radius * 3);

  addShake(Math.min(15, radius * 0.15), 0.28);

  for (const enemy of state.enemies) {
    if (enemy.hp <= 0) {
      continue;
    }
    const center = centerOf(enemy);
    if (Math.hypot(center.x - x, center.y - y) <= radius) {
      damageEnemy(enemy, damage, center.x, center.y);
    }
  }

  for (const turret of state.turrets) {
    if (turret.hp <= 0) {
      continue;
    }
    const center = centerOf(turret);
    if (Math.hypot(center.x - x, center.y - y) <= radius) {
      damageEnemy(turret, damage, center.x, center.y);
    }
  }

  if (state.boss.hp > 0) {
    const center = centerOf(state.boss);
    if (Math.hypot(center.x - x, center.y - y) <= radius + 36) {
      damageEnemy(state.boss, damage, center.x, center.y);
    }
  }
}

function damagePlayer(amount) {
  const player = state.player;
  if (player.invulnerability > 0 || state.victory || state.gameOver) {
    return;
  }

  if (state.vehicle.occupied && !state.vehicle.destroyed) {
    damageVehicle(amount);
    return;
  }

  player.hp -= amount;
  player.invulnerability = 1;
  player.hurtTimer = 0.2;
  spawnEffect(player.x + player.width / 2, player.y + player.height / 2, "#fff1a6", 20, 0.26, 130);
  addShake(7, 0.18);

  if (player.hp <= 0) {
    player.hp = 0;
    state.gameOver = true;
    state.messageTimer = 0;
  }
}

function damageVehicle(amount) {
  const vehicle = state.vehicle;
  if (!vehicle.occupied || vehicle.destroyed || vehicle.invulnerability > 0) {
    return;
  }

  vehicle.hp -= amount;
  vehicle.invulnerability = 0.35;
  addShake(8, 0.2);
  spawnEffect(vehicle.x + vehicle.width / 2, vehicle.y + 10, "#ffe08a", 18, 0.2, 100);

  if (vehicle.hp <= 0) {
    vehicle.hp = 0;
    vehicle.destroyed = true;
    vehicle.occupied = false;
    state.player.invulnerability = 1.6;
    state.player.x = vehicle.x + vehicle.width + 8;
    state.player.y = FLOOR_Y - state.player.height;
    state.player.vy = -360;
    explodeAt(vehicle.x + vehicle.width / 2, vehicle.y + vehicle.height / 2, 120, 4);
    spawnFloatingText("SLUG LOST!", vehicle.x - 10, vehicle.y - 20, "#ff8a4d", 22);
  }
}

function firePlayerBullet() {
  const player = state.player;
  if (player.shootCooldown > 0 || state.victory || state.gameOver) {
    return false;
  }

  if (state.vehicle.occupied && !state.vehicle.destroyed) {
    return fireVehicleCannon();
  }

  const direction = player.facing;
  const originX = player.x + (direction > 0 ? player.width : -12);
  const originY = player.y + (player.crouching ? 39 : 24);
  const heavy = player.weapon === "heavy" && player.weaponAmmo > 0;
  const shotgun = player.weapon === "shotgun" && player.weaponAmmo > 0;
  const flame = player.weapon === "flame" && player.weaponAmmo > 0;

  player.shootCooldown = heavy ? 0.075 : shotgun ? 0.28 : flame ? 0.06 : player.crouching ? 0.14 : 0.16;

  if (shotgun) {
    const spreads = [-0.22, -0.1, 0, 0.1, 0.22];
    for (const spread of spreads) {
      state.bullets.push({
        x: originX,
        y: originY,
        width: 10,
        height: 4,
        vx: BULLET_SPEED * 0.95 * direction,
        vy: BULLET_SPEED * spread,
        damage: 1,
        ttl: 0.22,
        color: "#ffe8a3",
        trailColor: "#fff5c4"
      });
    }
    spawnEffect(originX + direction * 4, originY + 2, "#ffe08a", 12, 0.1, 90);
  } else if (flame) {
    state.bullets.push({
      x: originX,
      y: originY - 2,
      width: 22,
      height: 12,
      vx: BULLET_SPEED * 0.52 * direction,
      vy: 0,
      damage: 0.45,
      ttl: 0.2,
      pierce: true,
      color: "#ff9b45",
      growth: 24,
      trailColor: "#ffcf7a"
    });
    spawnEffect(originX + direction * 4, originY + 2, "#ff9b45", 13, 0.12, 95);
  } else {
    state.bullets.push({
      x: originX,
      y: originY,
      width: heavy ? 18 : 14,
      height: 5,
      vx: (heavy ? BULLET_SPEED * 1.1 : BULLET_SPEED) * direction,
      vy: 0,
      damage: heavy ? 2 : 1,
      color: heavy ? "#ffd25f" : "#fff6cf",
      trailColor: heavy ? "#fff0a8" : "#ffffff"
    });
    spawnEffect(originX + direction * 4, originY + 2, "#ffe08a", 8, 0.08, 80);
  }

  if (heavy || shotgun || flame) {
    player.weaponAmmo -= 1;
    if (player.weaponAmmo <= 0) {
      const label = heavy ? "H 枪耗尽" : shotgun ? "S 枪耗尽" : "F 枪耗尽";
      player.weapon = "normal";
      player.weaponAmmo = Infinity;
      spawnFloatingText(label, player.x, player.y - 16, "#d8d8d8", 16);
    }
  }
  return true;
}

function fireVehicleCannon() {
  const vehicle = state.vehicle;
  const player = state.player;
  if (!vehicle.occupied || vehicle.destroyed || vehicle.cannonCooldown > 0) {
    return false;
  }

  vehicle.cannonCooldown = 0.45;
  player.shootCooldown = 0.45;
  const direction = player.facing;
  const originX = vehicle.x + (direction > 0 ? vehicle.width : -12);
  const originY = vehicle.y + 10;

  state.bullets.push({
    x: originX,
    y: originY,
    width: 18,
    height: 10,
    vx: 520 * direction,
    vy: 0,
    damage: 3,
    explosiveRadius: 72,
    explosiveDamage: 3,
    color: "#ffb84d",
    trailColor: "#ffe0a6"
  });

  vehicle.flashTimer = 0.12;
  spawnEffect(originX, originY + 4, "#ffe08a", 12, 0.1, 90);
  addShake(5, 0.12);
  return true;
}

function throwGrenade() {
  const player = state.player;
  if (state.vehicle.occupied || player.grenadeCooldown > 0 || player.grenades <= 0 || state.victory || state.gameOver) {
    return false;
  }

  player.grenadeCooldown = 0.45;
  player.grenades -= 1;
  const direction = player.facing;

  state.grenades.push({
    x: player.x + player.width / 2,
    y: player.y + 18,
    width: 12,
    height: 12,
    vx: GRENADE_SPEED_X * direction,
    vy: -GRENADE_SPEED_Y,
    fuse: 1.1,
    radius: 88,
    damage: 3
  });

  spawnEffect(player.x + player.width / 2, player.y + 20, "#cdd7e1", 6, 0.12, 60);
  return true;
}

function fireEnemyBullet(enemy, targetX, targetY) {
  const originX = enemy.x + enemy.width / 2;
  const originY = enemy.y + enemy.height / 2;
  const dx = targetX - originX;
  const dy = targetY - originY;
  const length = Math.max(1, Math.hypot(dx, dy));

  state.enemyBullets.push({
    x: originX,
    y: originY,
    width: enemy.type === "boss" ? 18 : 10,
    height: enemy.type === "boss" ? 18 : 10,
    vx: (dx / length) * enemy.projectileSpeed,
    vy: (dy / length) * enemy.projectileSpeed,
    damage: enemy.damage,
    color: enemy.type === "boss" ? enemy.gunColor || "#ff8a4d" : enemy.bulletColor || "#ffd966",
    trailColor: enemy.type === "boss" ? enemy.glowColor || "#ffd3a1" : "#fff0b5"
  });
}

function fireEnemySpread(enemy, direction) {
  const originX = enemy.x + enemy.width / 2;
  const originY = enemy.y + enemy.height / 2;
  const spreads = [-0.22, 0, 0.22];

  for (const spread of spreads) {
    state.enemyBullets.push({
      x: originX,
      y: originY - 8,
      width: 14,
      height: 10,
      vx: 280 * direction,
      vy: 280 * spread,
      damage: 1,
      color: "#ff9b45",
      trailColor: "#ffd6a3"
    });
  }
}

function fireBossVolley(boss, targetX, targetY) {
  const originX = boss.x + boss.width / 2;
  const originY = boss.y + boss.height / 2 - 10;
  const direction = targetX >= originX ? 1 : -1;
  const spreads = boss.phase >= 3 ? [-0.34, -0.17, 0, 0.17, 0.34] : [-0.2, 0, 0.2];
  const speed = boss.phase >= 3 ? 340 : 300;

  for (const spread of spreads) {
    state.enemyBullets.push({
      x: originX,
      y: originY,
      width: boss.phase >= 3 ? 16 : 14,
      height: boss.phase >= 3 ? 12 : 10,
      vx: speed * direction,
      vy: speed * spread,
      damage: 1,
      color: boss.gunColor || "#ff9b45",
      trailColor: boss.glowColor || "#ffd3a1"
    });
  }
}

function spawnIcicleRain(boss, targetX) {
  const count = boss.phase >= 3 ? 6 : 4;
  const spacing = boss.phase >= 3 ? 62 : 78;
  const startX = clamp(targetX - Math.floor(count / 2) * spacing, 120, WORLD_WIDTH - 220);

  for (let i = 0; i < count; i += 1) {
    const x = startX + i * spacing + (Math.random() - 0.5) * 18;
    state.hazards.push({
      type: "icicle",
      x,
      y: -60 - i * 18,
      width: 14,
      height: 34,
      vx: 0,
      vy: 380 + i * 18,
      damage: 1,
      ttl: 3.2
    });
    spawnEffect(x + 7, 44 + i * 8, "#dff6ff", 8, 0.22, 20);
  }
  spawnFloatingText("ICE STORM!", targetX - 40, 122, "#dff6ff", 20);
}

function spawnIceWallPattern(boss, targetX) {
  const candidateCenters = [targetX - 180, targetX - 70, targetX + 70, targetX + 180];
  const columns = candidateCenters.filter((center) => Math.abs(center - targetX) > 52);
  for (const center of columns) {
    const x = clamp(center - 15, 160, WORLD_WIDTH - 220);
    state.hazards.push({
      type: "iceWall",
      x,
      y: FLOOR_Y - 12,
      width: 30,
      height: 76,
      damage: 1,
      ttl: 1.35,
      riseTimer: 0.34,
      activeHeight: 0
    });
  }
  spawnFloatingText("ICE WALL!", clamp(targetX - 44, 120, WORLD_WIDTH - 180), FLOOR_Y - 94, "#b9f3ff", 20);
}

function spawnSandBurst(boss, targetX) {
  const count = boss.phase >= 3 ? 7 : 5;
  const spacing = boss.phase >= 3 ? 56 : 72;
  const startX = clamp(targetX - Math.floor(count / 2) * spacing, 140, WORLD_WIDTH - 240);

  for (let i = 0; i < count; i += 1) {
    const x = startX + i * spacing + (Math.random() - 0.5) * 22;
    const drift = (i - (count - 1) / 2) * 26;
    state.hazards.push({
      type: "sandShard",
      x,
      y: -40 - i * 18,
      width: 18,
      height: 28,
      vx: drift,
      vy: 310 + i * 16,
      damage: 1,
      ttl: 3.1
    });
    spawnEffect(x + 8, 56 + i * 7, "#ffe2ae", 8, 0.2, 18);
  }
  spawnFloatingText("SAND BURST!", targetX - 52, 122, "#ffe1a8", 20);
}

function spawnSandPillarPattern(boss, targetX) {
  const candidateCenters = [targetX - 190, targetX - 84, targetX + 84, targetX + 190];
  const columns = candidateCenters.filter((center) => Math.abs(center - targetX) > 56);
  for (const center of columns) {
    const x = clamp(center - 18, 160, WORLD_WIDTH - 230);
    state.hazards.push({
      type: "sandPillar",
      x,
      y: FLOOR_Y - 12,
      width: 36,
      height: 82,
      damage: 1,
      ttl: 1.45,
      riseTimer: 0.28,
      activeHeight: 0
    });
  }
  spawnFloatingText("RUIN SPIKES!", clamp(targetX - 58, 120, WORLD_WIDTH - 180), FLOOR_Y - 94, "#ffd894", 20);
}

function spawnMissileRain(boss, targetX) {
  const count = boss.phase >= 3 ? 6 : 4;
  const spacing = boss.phase >= 3 ? 68 : 84;
  const startX = clamp(targetX - Math.floor(count / 2) * spacing, 150, WORLD_WIDTH - 240);

  for (let i = 0; i < count; i += 1) {
    const x = startX + i * spacing + (Math.random() - 0.5) * 16;
    state.hazards.push({
      type: "missile",
      x,
      y: -72 - i * 22,
      width: 16,
      height: 38,
      vx: 0,
      vy: 400 + i * 14,
      damage: 1,
      ttl: 3
    });
    spawnEffect(x + 8, 54 + i * 8, "#d6fbff", 8, 0.2, 20);
  }
  spawnFloatingText("MISSILE RAIN!", targetX - 56, 122, "#d7fbff", 20);
}

function spawnLaserFencePattern(boss, targetX) {
  const candidateCenters = [targetX - 196, targetX - 86, targetX + 86, targetX + 196];
  const columns = candidateCenters.filter((center) => Math.abs(center - targetX) > 58);
  for (const center of columns) {
    const x = clamp(center - 16, 160, WORLD_WIDTH - 230);
    state.hazards.push({
      type: "laserFence",
      x,
      y: FLOOR_Y - 12,
      width: 32,
      height: 88,
      damage: 1,
      ttl: 1.55,
      riseTimer: 0.26,
      activeHeight: 0
    });
  }
  spawnFloatingText("LASER GRID!", clamp(targetX - 52, 120, WORLD_WIDTH - 180), FLOOR_Y - 94, "#b8f7ff", 20);
}

function spawnWindBladeRain(boss, targetX) {
  const count = boss.phase >= 3 ? 6 : 4;
  const spacing = boss.phase >= 3 ? 70 : 86;
  const startX = clamp(targetX - Math.floor(count / 2) * spacing, 140, WORLD_WIDTH - 240);

  for (let i = 0; i < count; i += 1) {
    const x = startX + i * spacing + (Math.random() - 0.5) * 18;
    const drift = (i - (count - 1) / 2) * 22;
    state.hazards.push({
      type: "windBlade",
      x,
      y: -54 - i * 16,
      width: 20,
      height: 20,
      vx: drift,
      vy: 360 + i * 14,
      damage: 1,
      ttl: 3
    });
    spawnEffect(x + 10, 58 + i * 7, "#efffb2", 8, 0.2, 20);
  }
  spawnFloatingText("WIND CUTTER!", targetX - 56, 122, "#efffb2", 20);
}

function spawnThornWallPattern(boss, targetX) {
  const candidateCenters = [targetX - 190, targetX - 82, targetX + 82, targetX + 190];
  const columns = candidateCenters.filter((center) => Math.abs(center - targetX) > 56);
  for (const center of columns) {
    const x = clamp(center - 18, 160, WORLD_WIDTH - 230);
    state.hazards.push({
      type: "thornWall",
      x,
      y: FLOOR_Y - 12,
      width: 36,
      height: 86,
      damage: 1,
      ttl: 1.5,
      riseTimer: 0.28,
      activeHeight: 0
    });
  }
  spawnFloatingText("THORN FENCE!", clamp(targetX - 60, 120, WORLD_WIDTH - 180), FLOOR_Y - 94, "#d6ff8a", 20);
}

function spawnDepthChargeRain(boss, targetX) {
  const count = boss.phase >= 3 ? 6 : 4;
  const spacing = boss.phase >= 3 ? 74 : 90;
  const startX = clamp(targetX - Math.floor(count / 2) * spacing, 150, WORLD_WIDTH - 240);

  for (let i = 0; i < count; i += 1) {
    const x = startX + i * spacing + (Math.random() - 0.5) * 18;
    state.hazards.push({
      type: "depthCharge",
      x,
      y: -58 - i * 20,
      width: 18,
      height: 28,
      vx: 0,
      vy: 350 + i * 18,
      damage: 1,
      ttl: 3.1
    });
    spawnEffect(x + 9, 56 + i * 8, "#bdf8ff", 8, 0.2, 20);
  }
  spawnFloatingText("DEPTH BOMB!", targetX - 52, 122, "#c7fbff", 20);
}

function spawnSteamColumnPattern(boss, targetX) {
  const candidateCenters = [targetX - 192, targetX - 86, targetX + 86, targetX + 192];
  const columns = candidateCenters.filter((center) => Math.abs(center - targetX) > 58);
  for (const center of columns) {
    const x = clamp(center - 17, 160, WORLD_WIDTH - 230);
    state.hazards.push({
      type: "steamColumn",
      x,
      y: FLOOR_Y - 12,
      width: 34,
      height: 90,
      damage: 1,
      ttl: 1.5,
      riseTimer: 0.24,
      activeHeight: 0
    });
  }
  spawnFloatingText("STEAM BURST!", clamp(targetX - 56, 120, WORLD_WIDTH - 180), FLOOR_Y - 94, "#c7fbff", 20);
}

function spawnRuinAmbush(targetX) {
  const ambushers = [
    createEnemy({ type: "patrol", x: clamp(targetX - 80, 140, WORLD_WIDTH - 220), y: FLOOR_Y - 52, patrolMin: clamp(targetX - 120, 120, WORLD_WIDTH - 260), patrolMax: clamp(targetX - 10, 200, WORLD_WIDTH - 180), hp: 3, speed: 92, color: "#bf7d45", bulletColor: "#ffe0a8", scoreValue: 520 }),
    createEnemy({ type: "sniper", x: clamp(targetX + 60, 220, WORLD_WIDTH - 180), y: FLOOR_Y - 52, stationary: true, hp: 2, shootInterval: 1.1, color: "#d29a5a", bulletColor: "#ffe7bf", scoreValue: 560 })
  ];
  for (const ambusher of ambushers) {
    state.enemies.push(ambusher);
    spawnEffect(ambusher.x + ambusher.width / 2, ambusher.y + 24, "#ffd894", 16, 0.2, 80);
  }
}

function spawnGliderAmbush(targetX) {
  const gliders = [
    createEnemy({ type: "glider", x: clamp(targetX - 120, 160, WORLD_WIDTH - 260), y: 168, baseY: 168, patrolMin: clamp(targetX - 160, 120, WORLD_WIDTH - 320), patrolMax: clamp(targetX + 80, 260, WORLD_WIDTH - 120), width: 52, height: 34, hp: 3, speed: 124, shootInterval: 1.25, aimRange: 600, color: "#8fb566", bulletColor: "#f5ffd2", floatAmplitude: 18, scoreValue: 720 }),
    createEnemy({ type: "glider", x: clamp(targetX + 30, 220, WORLD_WIDTH - 200), y: 206, baseY: 206, patrolMin: clamp(targetX - 60, 120, WORLD_WIDTH - 260), patrolMax: clamp(targetX + 180, 320, WORLD_WIDTH - 120), width: 52, height: 34, hp: 3, speed: 118, shootInterval: 1.4, aimRange: 560, color: "#9ec06f", bulletColor: "#f5ffd2", floatAmplitude: 14, phaseOffset: 1.2, scoreValue: 720 })
  ];
  for (const glider of gliders) {
    state.enemies.push(glider);
    spawnEffect(glider.x + glider.width / 2, glider.y + 10, "#eaffb8", 16, 0.2, 80);
  }
}

function triggerStageEvent(event) {
  const targetX = clamp(state.player.x + (event.targetOffset ?? 120), 140, WORLD_WIDTH - 220);
  const phaseTwoBoss = { phase: 2 };

  if (event.kind === "sandBurst") {
    spawnSandBurst(phaseTwoBoss, targetX);
  } else if (event.kind === "sandPillar") {
    spawnSandPillarPattern(phaseTwoBoss, targetX);
  } else if (event.kind === "missileRain") {
    spawnMissileRain(phaseTwoBoss, targetX);
  } else if (event.kind === "laserFence") {
    spawnLaserFencePattern(phaseTwoBoss, targetX);
  } else if (event.kind === "windBlade") {
    spawnWindBladeRain(phaseTwoBoss, targetX);
  } else if (event.kind === "thornWall") {
    spawnThornWallPattern(phaseTwoBoss, targetX);
  } else if (event.kind === "depthCharge") {
    spawnDepthChargeRain(phaseTwoBoss, targetX);
  } else if (event.kind === "steamColumn") {
    spawnSteamColumnPattern(phaseTwoBoss, targetX);
  } else if (event.kind === "ruinAmbush") {
    spawnRuinAmbush(targetX);
  } else if (event.kind === "gliderAmbush") {
    spawnGliderAmbush(targetX);
  } else {
    return;
  }

  announceStageEvent(event.notice, event.color);
  addShake(5, 0.12);
}

function updateStageEvents() {
  if (!state.stageEvents || state.stageEvents.length === 0 || state.stageBannerTimer > 0 || state.stageClear || state.victory || state.gameOver) {
    return;
  }

  for (const event of state.stageEvents) {
    if (event.triggered || state.player.x < event.x) {
      continue;
    }
    event.triggered = true;
    triggerStageEvent(event);
  }
}

function handlePlayerInput() {
  const player = state.player;
  if (state.vehicle.occupied && !state.vehicle.destroyed) {
    player.crouching = false;
    return;
  }
  let move = 0;

  if (keys.has("a") || keys.has("arrowleft")) {
    move -= 1;
  }
  if (keys.has("d") || keys.has("arrowright")) {
    move += 1;
  }

  player.crouching = player.onGround && (keys.has("s") || keys.has("arrowdown"));
  const desiredSpeed = move * (player.crouching ? PLAYER_SPEED * 0.48 : PLAYER_SPEED);
  if (state.stageTheme === "snow" && player.onGround) {
    if (move !== 0) {
      player.vx += (desiredSpeed - player.vx) * 0.2;
    } else {
      player.vx *= player.crouching ? 0.7 : 0.92;
      if (Math.abs(player.vx) < 8) {
        player.vx = 0;
      }
    }
  } else {
    player.vx = desiredSpeed;
  }

  if (move !== 0) {
    player.facing = move > 0 ? 1 : -1;
    player.stepTimer += 1;
  }

  const jumpPressed = keys.has("w") || keys.has("arrowup") || keys.has(" ");
  if (jumpPressed && player.onGround && !player.crouching) {
    player.vy = -JUMP_SPEED;
    player.onGround = false;
  }

  if (keys.has("j") || keys.has("f")) {
    firePlayerBullet();
  }
  if (keys.has("k") || keys.has("g")) {
    throwGrenade();
  }
}

function updateVehicle(dt) {
  const vehicle = state.vehicle;
  const player = state.player;

  vehicle.cannonCooldown = Math.max(0, vehicle.cannonCooldown - dt);
  vehicle.invulnerability = Math.max(0, vehicle.invulnerability - dt);
  vehicle.flashTimer = Math.max(0, vehicle.flashTimer - dt);
  vehicle.snowTrackCooldown = Math.max(0, vehicle.snowTrackCooldown - dt);

  if (vehicle.destroyed) {
    return;
  }

  const playerNearVehicle =
    !vehicle.occupied &&
    player.vehicleCooldown <= 0 &&
    Math.abs(player.x - vehicle.x) < 56 &&
    Math.abs(player.y - vehicle.y) < 60;

  if (playerNearVehicle && keys.has("e")) {
    vehicle.occupied = true;
    player.vehicleCooldown = 0.35;
    player.invulnerability = Math.max(player.invulnerability, 0.4);
    spawnFloatingText("IN SLUG", vehicle.x - 8, vehicle.y - 18, "#ffd25f", 18);
  }

  if (vehicle.occupied) {
    let move = 0;
    if (keys.has("a") || keys.has("arrowleft")) {
      move -= 1;
    }
    if (keys.has("d") || keys.has("arrowright")) {
      move += 1;
    }

    const targetVx = move * 210;
    if (state.stageTheme === "snow") {
      if (move !== 0) {
        vehicle.vx += (targetVx - vehicle.vx) * 0.16;
      } else {
        vehicle.vx *= 0.9;
        if (Math.abs(vehicle.vx) < 6) {
          vehicle.vx = 0;
        }
      }
    } else {
      vehicle.vx = targetVx;
    }
    vehicle.x += vehicle.vx * dt;
    vehicle.x = clamp(vehicle.x, 0, WORLD_WIDTH - vehicle.width);
    if (state.stageTheme === "snow" && Math.abs(vehicle.vx) > 80 && vehicle.snowTrackCooldown <= 0) {
      spawnSnowTrack(vehicle.x + 10, 42, Math.min(1.6, Math.abs(vehicle.vx) / 210));
      vehicle.snowTrackCooldown = 0.08;
    }

    if (move !== 0) {
      player.facing = move > 0 ? 1 : -1;
      player.stepTimer += 0.3;
    }

    if (keys.has("e") && player.vehicleCooldown <= 0) {
      vehicle.occupied = false;
      player.vehicleCooldown = 0.35;
      player.x = vehicle.x + (player.facing > 0 ? vehicle.width + 8 : -player.width - 8);
      player.y = FLOOR_Y - player.height;
      spawnFloatingText("OUT", vehicle.x + 16, vehicle.y - 16, "#d8d8d8", 16);
    }
  }
}

function resolveWorldCollision(entity, dt) {
  entity.vy += GRAVITY * dt;
  entity.x += entity.vx * dt;
  entity.y += entity.vy * dt;

  entity.onGround = false;

  for (const platform of platforms) {
    if (!rectsOverlap(entity, platform)) {
      continue;
    }

    const prevBottom = entity.y - entity.vy * dt + entity.height;
    const prevTop = entity.y - entity.vy * dt;
    const prevRight = entity.x - entity.vx * dt + entity.width;
    const prevLeft = entity.x - entity.vx * dt;

    if (prevBottom <= platform.y) {
      entity.y = platform.y - entity.height;
      entity.vy = 0;
      entity.onGround = true;
    } else if (prevTop >= platform.y + platform.height) {
      entity.y = platform.y + platform.height;
      entity.vy = 40;
    } else if (prevRight <= platform.x) {
      entity.x = platform.x - entity.width;
      entity.vx = 0;
    } else if (prevLeft >= platform.x + platform.width) {
      entity.x = platform.x + platform.width;
      entity.vx = 0;
    }
  }

  entity.x = clamp(entity.x, 0, WORLD_WIDTH - entity.width);
  if (entity.y > VIEW_HEIGHT + 220) {
    entity.y = 120;
    entity.vy = 0;
  }
}

function updatePlayer(dt) {
  const player = state.player;
  player.vehicleCooldown = Math.max(0, player.vehicleCooldown - dt);
  handlePlayerInput();
  player.shootCooldown = Math.max(0, player.shootCooldown - dt);
  player.grenadeCooldown = Math.max(0, player.grenadeCooldown - dt);
  player.invulnerability = Math.max(0, player.invulnerability - dt);
  player.hurtTimer = Math.max(0, player.hurtTimer - dt);
  player.snowTrackCooldown = Math.max(0, player.snowTrackCooldown - dt);
  if (state.vehicle.occupied && !state.vehicle.destroyed) {
    player.onGround = true;
    player.x = state.vehicle.x + 18;
    player.y = state.vehicle.y - 28;
    player.vx = 0;
    player.vy = 0;
    return;
  }
  resolveWorldCollision(player, dt);
  if (state.stageTheme === "snow" && player.onGround && Math.abs(player.vx) > 90 && player.snowTrackCooldown <= 0) {
    spawnSnowTrack(player.x + 4, 20, Math.min(1.4, Math.abs(player.vx) / PLAYER_SPEED));
    player.snowTrackCooldown = 0.06;
  }
}

function updateEnemies(dt) {
  const player = state.player;
  const playerCenter = centerOf(player);

  for (const enemy of state.enemies) {
    enemy.hurtTimer = Math.max(0, enemy.hurtTimer - dt);
    if (enemy.hp <= 0) {
      continue;
    }

    if (enemy.type === "mech") {
      enemy.y = FLOOR_Y - enemy.height;
    } else if (enemy.type === "glider") {
      enemy.vx = enemy.speed * enemy.direction;
      enemy.x += enemy.vx * dt;
      enemy.y = enemy.baseY + Math.sin((enemy.x * 0.018) + enemy.phaseOffset + state.player.stepTimer * 0.08) * enemy.floatAmplitude;

      if (enemy.x <= enemy.patrolMin) {
        enemy.x = enemy.patrolMin;
        enemy.direction = 1;
      } else if (enemy.x + enemy.width >= enemy.patrolMax) {
        enemy.x = enemy.patrolMax - enemy.width;
        enemy.direction = -1;
      }
    } else if (!enemy.stationary) {
      enemy.vx = enemy.speed * enemy.direction;
      resolveWorldCollision(enemy, dt);

      if (enemy.x <= enemy.patrolMin) {
        enemy.x = enemy.patrolMin;
        enemy.direction = 1;
      } else if (enemy.x + enemy.width >= enemy.patrolMax) {
        enemy.x = enemy.patrolMax - enemy.width;
        enemy.direction = -1;
      }
    }

    if (rectsOverlap(player, enemy)) {
      damagePlayer(1);
    }

    const enemyCenter = centerOf(enemy);
    const dx = playerCenter.x - enemyCenter.x;
    const dy = playerCenter.y - enemyCenter.y;
    const visibleWindow = enemy.x > state.cameraX - 40 && enemy.x < state.cameraX + VIEW_WIDTH + 80;
    const engaged = state.stageBannerTimer <= 0 && visibleWindow && Math.abs(dx) < (enemy.type === "glider" ? 420 : 320) && Math.abs(dy) < (enemy.type === "glider" ? 280 : 220);
    if (!engaged) {
      continue;
    }

    enemy.direction = dx >= 0 ? 1 : -1;
    enemy.shootCooldown -= dt;

    if (Math.abs(dx) < enemy.aimRange && Math.abs(dy) < (enemy.type === "glider" ? 240 : 180) && enemy.shootCooldown <= 0) {
      if (enemy.type === "mech") {
        fireEnemySpread(enemy, enemy.direction);
        enemy.shootCooldown = enemy.shootInterval;
      } else {
        fireEnemyBullet(enemy, playerCenter.x, playerCenter.y - (player.crouching ? 10 : 0));
        enemy.shootCooldown = enemy.shootInterval;
      }
    }
  }

  updateTurrets(dt, playerCenter);

  const aliveTurrets = state.turrets.filter((turret) => turret.hp > 0);
  if (aliveTurrets.length > 0 && player.x > 2140 && player.x < 3000) {
    state.interceptBannerTimer = Math.max(state.interceptBannerTimer, 1.4);
  }

  if (!state.bossAwake && player.x > 2860) {
    state.bossAwake = true;
    state.warningTimer = 2.8;
    if (!state.bossBannerPlayed) {
      state.bossBannerPlayed = true;
      spawnFloatingText("WARNING!", player.x + 80, 88, "#ff8a4d", 28);
    }
  }

  const boss = state.boss;
  if (boss.hp > 0 && state.bossAwake) {
    boss.flashTimer = Math.max(0, boss.flashTimer - dt);
    boss.hurtTimer = Math.max(0, boss.hurtTimer - dt);
    boss.pulseTimer += dt;
    boss.barrageCooldown = Math.max(0, boss.barrageCooldown - dt);
    boss.stormCooldown = Math.max(0, boss.stormCooldown - dt);
    const nextPhase = boss.hp <= boss.maxHp * 0.33 ? 3 : boss.hp <= boss.maxHp * 0.66 ? 2 : 1;
    if (nextPhase !== boss.phase) {
      boss.phase = nextPhase;
      spawnFloatingText(`PHASE ${boss.phase}`, boss.x - 6, boss.y - 26, "#ffe08a", 18);
      addShake(6, 0.14);
    }
    boss.shootInterval = boss.phase >= 3 ? 0.5 : boss.phase === 2 ? 0.68 : 0.8;
    boss.shootCooldown -= dt;
    if (boss.shootCooldown <= 0) {
      fireEnemyBullet(boss, playerCenter.x, playerCenter.y);
      boss.shootCooldown = boss.shootInterval;
      boss.flashTimer = 0.14;
      addShake(4, 0.08);
    }
    if (boss.phase >= 2 && boss.barrageCooldown <= 0) {
      fireBossVolley(boss, playerCenter.x, playerCenter.y);
      boss.barrageCooldown = boss.phase >= 3 ? 1.4 : 2.1;
      boss.flashTimer = 0.18;
      addShake(5, 0.1);
    }
    if (state.stageTheme === "snow" && boss.phase >= 2 && boss.stormCooldown <= 0) {
      spawnIcicleRain(boss, playerCenter.x);
      boss.stormCooldown = boss.phase >= 3 ? 1.5 : 2.3;
      addShake(5, 0.12);
    } else if (state.stageTheme === "desert" && boss.phase >= 2 && boss.stormCooldown <= 0) {
      spawnSandBurst(boss, playerCenter.x);
      boss.stormCooldown = boss.phase >= 3 ? 1.45 : 2.2;
      addShake(5, 0.12);
    } else if (state.stageTheme === "city" && boss.phase >= 2 && boss.stormCooldown <= 0) {
      spawnMissileRain(boss, playerCenter.x);
      boss.stormCooldown = boss.phase >= 3 ? 1.35 : 2;
      addShake(5, 0.12);
    } else if (state.stageTheme === "grassland" && boss.phase >= 2 && boss.stormCooldown <= 0) {
      spawnWindBladeRain(boss, playerCenter.x);
      boss.stormCooldown = boss.phase >= 3 ? 1.32 : 1.95;
      addShake(5, 0.12);
    } else if (state.stageTheme === "harbor" && boss.phase >= 2 && boss.stormCooldown <= 0) {
      spawnDepthChargeRain(boss, playerCenter.x);
      boss.stormCooldown = boss.phase >= 3 ? 1.28 : 1.9;
      addShake(5, 0.12);
    }
    boss.wallCooldown = Math.max(0, boss.wallCooldown - dt);
    if (state.stageTheme === "snow" && boss.phase >= 3 && boss.wallCooldown <= 0) {
      spawnIceWallPattern(boss, playerCenter.x);
      boss.wallCooldown = 3.2;
      addShake(6, 0.15);
    } else if (state.stageTheme === "desert" && boss.phase >= 3 && boss.wallCooldown <= 0) {
      spawnSandPillarPattern(boss, playerCenter.x);
      boss.wallCooldown = 3.05;
      addShake(6, 0.15);
    } else if (state.stageTheme === "city" && boss.phase >= 3 && boss.wallCooldown <= 0) {
      spawnLaserFencePattern(boss, playerCenter.x);
      boss.wallCooldown = 2.9;
      addShake(6, 0.15);
    } else if (state.stageTheme === "grassland" && boss.phase >= 3 && boss.wallCooldown <= 0) {
      spawnThornWallPattern(boss, playerCenter.x);
      boss.wallCooldown = 2.95;
      addShake(6, 0.15);
    } else if (state.stageTheme === "harbor" && boss.phase >= 3 && boss.wallCooldown <= 0) {
      spawnSteamColumnPattern(boss, playerCenter.x);
      boss.wallCooldown = 2.85;
      addShake(6, 0.15);
    }

    if (rectsOverlap(player, boss)) {
      damagePlayer(1);
    }
  }
}

function updateProjectiles(dt) {
  const livingTargets = [...state.enemies.filter((enemy) => enemy.hp > 0)];
  for (const turret of state.turrets) {
    if (turret.hp > 0) {
      livingTargets.push(turret);
    }
  }
  if (state.boss.hp > 0) {
    livingTargets.push(state.boss);
  }

  for (const bullet of state.bullets) {
    bullet.x += bullet.vx * dt;
    bullet.y += bullet.vy * dt;
    if (bullet.growth) {
      bullet.width += bullet.growth * dt;
    }
    if (bullet.ttl !== undefined) {
      bullet.ttl -= dt;
      if (bullet.ttl <= 0) {
        bullet.hit = true;
      }
    }
    bullet.hit = bullet.x > WORLD_WIDTH || bullet.x + bullet.width < 0;

    for (const crate of state.crates) {
      if (bullet.hit || crate.opened) {
        continue;
      }
      if (rectsOverlap(bullet, crate)) {
        if (!bullet.pierce) {
          bullet.hit = true;
        }
        breakCrate(crate);
      }
    }

    for (const target of livingTargets) {
      if (bullet.hit || target.hp <= 0) {
        continue;
      }

      if (rectsOverlap(bullet, target)) {
        if (!bullet.pierce) {
          bullet.hit = true;
        }
        damageEnemy(target, bullet.damage, bullet.x, bullet.y);
        if (bullet.explosiveRadius) {
          explodeAt(bullet.x, bullet.y, bullet.explosiveRadius, bullet.explosiveDamage || bullet.damage);
        }
      }
    }
  }

  for (const grenade of state.grenades) {
    grenade.vy += GRAVITY * dt;
    grenade.x += grenade.vx * dt;
    grenade.y += grenade.vy * dt;
    grenade.fuse -= dt;

    if (grenade.y + grenade.height >= FLOOR_Y) {
      grenade.y = FLOOR_Y - grenade.height;
      grenade.hit = true;
    }

    for (const platform of platforms.slice(1)) {
      if (rectsOverlap(grenade, platform) && grenade.vy > 0) {
        grenade.y = platform.y - grenade.height;
        grenade.hit = true;
      }
    }

    if (grenade.fuse <= 0 || grenade.hit) {
      grenade.expired = true;
      explodeAt(grenade.x + grenade.width / 2, grenade.y + grenade.height / 2, grenade.radius, grenade.damage);
    }
  }

  for (const bullet of state.enemyBullets) {
    bullet.x += bullet.vx * dt;
    bullet.y += bullet.vy * dt;
    if (bullet.x > WORLD_WIDTH + 100 || bullet.x < -100 || bullet.y > VIEW_HEIGHT + 100 || bullet.y < -100) {
      bullet.hit = true;
      continue;
    }
    if (!bullet.hit && state.vehicle.occupied && !state.vehicle.destroyed && rectsOverlap(bullet, state.vehicle)) {
      bullet.hit = true;
      damageVehicle(bullet.damage);
      continue;
    }
    if (!bullet.hit && rectsOverlap(bullet, state.player)) {
      bullet.hit = true;
      damagePlayer(bullet.damage);
    }
  }

  for (const hazard of state.hazards) {
    hazard.ttl -= dt;
    if (hazard.type === "iceWall" || hazard.type === "sandPillar" || hazard.type === "laserFence" || hazard.type === "thornWall" || hazard.type === "steamColumn") {
      hazard.riseTimer = Math.max(0, hazard.riseTimer - dt);
      if (hazard.riseTimer <= 0) {
        hazard.activeHeight = Math.min(hazard.height, hazard.activeHeight + 280 * dt);
      }
    } else {
      hazard.x += hazard.vx * dt;
      hazard.y += hazard.vy * dt;
      hazard.vy += GRAVITY * dt * 0.2;
    }

    if (hazard.ttl <= 0) {
      hazard.expired = true;
      continue;
    }

    const hitbox =
      hazard.type === "iceWall" || hazard.type === "sandPillar" || hazard.type === "laserFence" || hazard.type === "thornWall" || hazard.type === "steamColumn"
        ? {
            x: hazard.x,
            y: hazard.y + (hazard.height - hazard.activeHeight),
            width: hazard.width,
            height: hazard.activeHeight
          }
        : hazard;

    if (!hazard.expired && hitbox.height > 0 && state.vehicle.occupied && !state.vehicle.destroyed && rectsOverlap(hitbox, state.vehicle)) {
      hazard.expired = true;
      damageVehicle(hazard.damage);
      spawnEffect(hazard.x + hazard.width / 2, hazard.y + hazard.height / 2, hazard.type === "sandPillar" || hazard.type === "sandShard" ? "#ffd29a" : hazard.type === "laserFence" || hazard.type === "missile" ? "#b8f7ff" : hazard.type === "thornWall" || hazard.type === "windBlade" ? "#d6ff8a" : hazard.type === "steamColumn" || hazard.type === "depthCharge" ? "#c7fbff" : "#dff6ff", 16, 0.18, 60);
      continue;
    }

    if (!hazard.expired && hitbox.height > 0 && rectsOverlap(hitbox, state.player)) {
      hazard.expired = true;
      damagePlayer(hazard.damage);
      spawnEffect(hazard.x + hazard.width / 2, hazard.y + hazard.height / 2, hazard.type === "sandPillar" || hazard.type === "sandShard" ? "#ffd29a" : hazard.type === "laserFence" || hazard.type === "missile" ? "#b8f7ff" : hazard.type === "thornWall" || hazard.type === "windBlade" ? "#d6ff8a" : hazard.type === "steamColumn" || hazard.type === "depthCharge" ? "#c7fbff" : "#dff6ff", 16, 0.18, 60);
      continue;
    }

    if (hazard.type !== "iceWall" && hazard.type !== "sandPillar" && hazard.type !== "laserFence" && hazard.type !== "thornWall" && hazard.type !== "steamColumn" && hazard.y + hazard.height >= FLOOR_Y) {
      hazard.expired = true;
      if (hazard.type === "sandShard") {
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 4, "#ffe0a8", 18, 0.18, 55);
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 6, "#d5a86c", 11, 0.16, 35);
      } else if (hazard.type === "missile") {
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 4, "#d6fbff", 20, 0.18, 60);
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 6, "#65d7ff", 12, 0.16, 40);
        addShake(4, 0.08);
      } else if (hazard.type === "windBlade") {
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 4, "#efffb2", 18, 0.18, 55);
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 6, "#a2d85b", 11, 0.16, 35);
      } else if (hazard.type === "depthCharge") {
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 4, "#c7fbff", 22, 0.18, 60);
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 6, "#57d5ff", 13, 0.16, 40);
        addShake(4, 0.08);
      } else {
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 4, "#f2fbff", 16, 0.18, 55);
        spawnEffect(hazard.x + hazard.width / 2, FLOOR_Y - 6, "#8be1ff", 10, 0.16, 35);
      }
      addShake(3, 0.06);
    }
  }

  state.bullets = state.bullets.filter((bullet) => !bullet.hit);
  state.grenades = state.grenades.filter((grenade) => !grenade.expired);
  state.enemyBullets = state.enemyBullets.filter((bullet) => !bullet.hit);
  state.hazards = state.hazards.filter((hazard) => !hazard.expired);
}

function updateHostages(dt) {
  for (const hostage of state.hostages) {
    if (!hostage.rescued && rectsOverlap(state.player, hostage)) {
      hostage.rescued = true;
      hostage.timer = 1.2;
      state.score += 1000;
      spawnFloatingText("THANK YOU!", hostage.x - 12, hostage.y - 16, "#fff1a6", 20);
      spawnFloatingText("+1000", hostage.x, hostage.y - 34, "#ffd25f", 18);
    }

    if (hostage.rescued && !hostage.rewardDropped) {
      hostage.timer -= dt;
      if (hostage.timer <= 0) {
        hostage.rewardDropped = true;
        const rewardType = Math.random() > 0.5 ? "grenade" : "medkit";
        state.pickups.push(createPickup(hostage.x + 20, hostage.y - 12, rewardType));
      }
    }
  }
}

function updatePickups(dt) {
  for (const pickup of state.pickups) {
    pickup.ttl -= dt;
    pickup.vy += GRAVITY * dt * 0.65;
    pickup.y += pickup.vy * dt;
    if (pickup.y + pickup.height >= FLOOR_Y) {
      pickup.y = FLOOR_Y - pickup.height;
      pickup.vy = 0;
    }

    if (rectsOverlap(state.player, pickup)) {
      pickup.ttl = 0;
      grantPickup(pickup.type);
    }
  }

  state.pickups = state.pickups.filter((pickup) => pickup.ttl > 0);
}

function updateCrates() {
  state.crates = state.crates.filter((crate) => !crate.opened);
}

function updateEffects(dt) {
  for (const effect of state.effects) {
    effect.ttl -= dt;
    effect.radius += effect.growth * dt;
  }
  state.effects = state.effects.filter((effect) => effect.ttl > 0);

  for (const text of state.floatingTexts) {
    text.ttl -= dt;
    text.y += text.vy * dt;
  }
  state.floatingTexts = state.floatingTexts.filter((text) => text.ttl > 0);

  for (const mark of state.snowMarks) {
    mark.ttl -= dt;
  }
  state.snowMarks = state.snowMarks.filter((mark) => mark.ttl > 0);

  for (const fragment of state.fragments) {
    fragment.ttl -= dt;
    fragment.vy += GRAVITY * dt * 0.45;
    fragment.x += fragment.vx * dt;
    fragment.y += fragment.vy * dt;
  }
  state.fragments = state.fragments.filter((fragment) => fragment.ttl > 0 && fragment.y < VIEW_HEIGHT + 40);
}

function updateCamera(dt) {
  const target = state.player.x - VIEW_WIDTH * 0.35;
  state.cameraX = clamp(target, 0, WORLD_WIDTH - VIEW_WIDTH);

  if (state.shakeTime > 0) {
    state.shakeTime = Math.max(0, state.shakeTime - dt);
    if (state.shakeTime === 0) {
      state.shakePower = 0;
    }
  }
}

function update(dt) {
  state.stageBannerTimer = Math.max(0, state.stageBannerTimer - dt);
  state.warningTimer = Math.max(0, state.warningTimer - dt);
  state.interceptBannerTimer = Math.max(0, state.interceptBannerTimer - dt);
  state.eventNoticeTimer = Math.max(0, state.eventNoticeTimer - dt);

  if (state.stageClear) {
    state.messageTimer += dt;
    updateEffects(dt);
    if (state.messageTimer > 2.2) {
      resetGame(state.stageIndex + 1, {
        score: state.score,
        playerStats: {
          hp: state.player.hp,
          grenades: state.player.grenades,
          weapon: state.player.weapon,
          weaponAmmo: state.player.weaponAmmo
        }
      });
    }
    return;
  }

  if (state.victory || state.gameOver) {
    state.messageTimer += dt;
    updateEffects(dt);
    if (keys.has("r")) {
      resetGame(state.stageIndex);
    }
    return;
  }

  updatePlayer(dt);
  updateVehicle(dt);
  updateStageEvents();
  updateEnemies(dt);
  updateProjectiles(dt);
  updateHostages(dt);
  updatePickups(dt);
  updateCrates();
  updateEffects(dt);
  updateCamera(dt);
}

function drawBackground() {
  const cameraX = state.cameraX;
  if (state.stageTheme === "snow") {
    ctx.fillStyle = "#a8d8ff";
    ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

    const moonX = 760 - cameraX * 0.04;
    ctx.fillStyle = "#f5fbff";
    ctx.beginPath();
    ctx.arc(moonX, 84, 30, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#dff2ff";
    for (let i = 0; i < 6; i += 1) {
      const x = ((i * 250 - cameraX * 0.12) % (VIEW_WIDTH + 280)) - 60;
      ctx.beginPath();
      ctx.arc(x, 92 + (i % 2) * 12, 34, 0, Math.PI * 2);
      ctx.arc(x + 34, 96 + (i % 2) * 12, 26, 0, Math.PI * 2);
      ctx.arc(x - 26, 98 + (i % 2) * 12, 22, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = "#c4d8ea";
    for (let i = 0; i < 8; i += 1) {
      const baseX = i * 420 - cameraX * 0.2;
      ctx.beginPath();
      ctx.moveTo(baseX, 360);
      ctx.lineTo(baseX + 90, 190);
      ctx.lineTo(baseX + 190, 360);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(baseX + 140, 360);
      ctx.lineTo(baseX + 250, 210);
      ctx.lineTo(baseX + 360, 360);
      ctx.fill();
    }

    ctx.fillStyle = "#eaf6ff";
    for (let i = 0; i < 9; i += 1) {
      const driftX = i * 210 - cameraX * 0.45;
      ctx.beginPath();
      ctx.arc(driftX + 30, 430, 34, 0, Math.PI * 2);
      ctx.arc(driftX + 76, 436, 44, 0, Math.PI * 2);
      ctx.arc(driftX + 122, 428, 30, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = "#5d7385";
    for (let i = 0; i < 11; i += 1) {
      const trunkX = i * 280 - cameraX * 0.54;
      ctx.fillRect(trunkX + 20, 332, 10, 126);
      ctx.fillStyle = "#6e8ba0";
      ctx.beginPath();
      ctx.moveTo(trunkX - 6, 402);
      ctx.lineTo(trunkX + 25, 344);
      ctx.lineTo(trunkX + 56, 402);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(trunkX - 2, 372);
      ctx.lineTo(trunkX + 25, 324);
      ctx.lineTo(trunkX + 52, 372);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(trunkX + 2, 346);
      ctx.lineTo(trunkX + 25, 304);
      ctx.lineTo(trunkX + 48, 346);
      ctx.fill();
      ctx.fillStyle = "#5d7385";
    }

    ctx.fillStyle = "#e6f5ff";
    ctx.fillRect(0, FLOOR_Y, VIEW_WIDTH, VIEW_HEIGHT - FLOOR_Y);
    ctx.fillStyle = "#c8e7f8";
    for (let i = 0; i < 18; i += 1) {
      ctx.fillRect(i * 56 - (cameraX * 0.4) % 56, FLOOR_Y + 18 + (i % 2) * 6, 26, 5);
    }
    ctx.fillStyle = "#ffffffcc";
    for (let i = 0; i < 42; i += 1) {
      const flakeX = (i * 71 - cameraX * 0.18 + state.player.stepTimer * (8 + (i % 5))) % (VIEW_WIDTH + 40);
      const flakeY = (i * 27 + state.player.stepTimer * (4 + (i % 3))) % FLOOR_Y;
      ctx.fillRect(flakeX - 20, flakeY, 3, 3);
    }
    return;
  }

  if (state.stageTheme === "desert") {
    ctx.fillStyle = "#f2c67d";
    ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

    const sunX = 760 - cameraX * 0.04;
    ctx.fillStyle = "#fff2b3";
    ctx.beginPath();
    ctx.arc(sunX, 78, 40, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffffff22";
    ctx.fillRect(0, 0, VIEW_WIDTH, 110);

    ctx.fillStyle = "#f6d694";
    for (let i = 0; i < 6; i += 1) {
      const duneX = i * 260 - cameraX * 0.14;
      ctx.beginPath();
      ctx.moveTo(duneX - 40, 360);
      ctx.quadraticCurveTo(duneX + 100, 286 - (i % 2) * 24, duneX + 250, 360);
      ctx.lineTo(duneX + 250, 420);
      ctx.lineTo(duneX - 40, 420);
      ctx.fill();
    }

    ctx.fillStyle = "#d2a260";
    for (let i = 0; i < 9; i += 1) {
      const mesaX = i * 380 - cameraX * 0.22;
      ctx.fillRect(mesaX + 18, 246, 110, 122);
      ctx.fillRect(mesaX, 286, 154, 82);
      ctx.fillStyle = "#edd18f";
      ctx.fillRect(mesaX + 10, 280, 136, 9);
      ctx.fillStyle = "#d2a260";
    }

    ctx.fillStyle = "#8b6032";
    for (let i = 0; i < 7; i += 1) {
      const ruinX = i * 470 - cameraX * 0.48;
      ctx.fillRect(ruinX + 18, 316, 22, 142);
      ctx.fillRect(ruinX + 68, 290, 24, 168);
      ctx.fillRect(ruinX - 6, 360, 124, 16);
      ctx.fillStyle = "#b68a57";
      ctx.fillRect(ruinX + 8, 306, 96, 12);
      ctx.fillRect(ruinX + 26, 334, 10, 48);
      ctx.fillRect(ruinX + 72, 326, 12, 58);
      ctx.fillStyle = "#6a4724";
      ctx.fillRect(ruinX + 18, 384, 74, 10);
      ctx.fillRect(ruinX + 34, 402, 42, 6);
      ctx.fillStyle = "#d8b072";
      ctx.fillRect(ruinX + 32, 392, 18, 4);
      ctx.fillRect(ruinX + 56, 392, 18, 4);
      ctx.fillStyle = "#8b6032";
    }

    for (let i = 0; i < 5; i += 1) {
      const plateX = 360 + i * 520 - cameraX * 0.7;
      ctx.fillStyle = "#8f6a3f";
      ctx.fillRect(plateX, FLOOR_Y - 10, 54, 10);
      ctx.fillStyle = "#daba80";
      ctx.fillRect(plateX + 6, FLOOR_Y - 8, 42, 4);
      ctx.fillStyle = "#5a3b1d";
      ctx.fillRect(plateX + 20, FLOOR_Y - 6, 14, 2);
    }

    ctx.fillStyle = "#d7ab67";
    for (let i = 0; i < 9; i += 1) {
      const driftX = i * 200 - cameraX * 0.62;
      ctx.beginPath();
      ctx.moveTo(driftX, 410);
      ctx.quadraticCurveTo(driftX + 40, 388 - (i % 3) * 12, driftX + 120, 414);
      ctx.quadraticCurveTo(driftX + 170, 430, driftX + 220, 406);
      ctx.lineTo(driftX + 220, 460);
      ctx.lineTo(driftX, 460);
      ctx.fill();
    }

    ctx.fillStyle = "#d7b06f";
    ctx.fillRect(0, FLOOR_Y, VIEW_WIDTH, VIEW_HEIGHT - FLOOR_Y);
    ctx.fillStyle = "#bf9153";
    for (let i = 0; i < 22; i += 1) {
      ctx.fillRect(i * 48 - (cameraX * 0.58) % 48, FLOOR_Y + 22 + (i % 2) * 7, 20, 4);
    }
    ctx.fillStyle = "#fbe3b6";
    for (let i = 0; i < 28; i += 1) {
      const gustX = (i * 73 - cameraX * 0.26 + state.player.stepTimer * (6 + (i % 4))) % (VIEW_WIDTH + 60);
      const gustY = 116 + (i % 10) * 28;
      ctx.fillRect(gustX - 20, gustY, 12, 2);
    }
    return;
  }

  if (state.stageTheme === "city") {
    ctx.fillStyle = "#1f2940";
    ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

    const moonX = 740 - cameraX * 0.03;
    ctx.fillStyle = "#dff5ff";
    ctx.beginPath();
    ctx.arc(moonX, 86, 28, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#2e3c5d";
    for (let i = 0; i < 10; i += 1) {
      const towerX = i * 200 - cameraX * 0.16;
      const towerHeight = 140 + (i % 4) * 34;
      ctx.fillRect(towerX, FLOOR_Y - towerHeight - 30, 72, towerHeight + 30);
      ctx.fillRect(towerX + 50, FLOOR_Y - towerHeight - 76, 28, 46);
    }

    ctx.fillStyle = "#3d4b72";
    for (let i = 0; i < 12; i += 1) {
      const towerX = i * 150 - cameraX * 0.34;
      const towerHeight = 120 + (i % 5) * 30;
      ctx.fillRect(towerX, FLOOR_Y - towerHeight, 58, towerHeight);
      ctx.fillRect(towerX + 38, FLOOR_Y - towerHeight - 42, 18, 42);
      ctx.fillStyle = "#d6f7ff";
      for (let row = 0; row < 6; row += 1) {
        ctx.fillRect(towerX + 8, FLOOR_Y - towerHeight + 14 + row * 18, 8, 4);
        ctx.fillRect(towerX + 24, FLOOR_Y - towerHeight + 14 + row * 18, 8, 4);
        ctx.fillRect(towerX + 40, FLOOR_Y - towerHeight + 14 + row * 18, 8, 4);
      }
      ctx.fillStyle = "#3d4b72";
    }

    ctx.fillStyle = "#4d5871";
    for (let i = 0; i < 8; i += 1) {
      const bridgeX = i * 250 - cameraX * 0.52;
      ctx.fillRect(bridgeX, 366, 140, 14);
      ctx.fillRect(bridgeX + 18, 320, 12, 46);
      ctx.fillRect(bridgeX + 110, 320, 12, 46);
    }

    for (let i = 0; i < 5; i += 1) {
      const boardX = i * 280 - cameraX * 0.42;
      ctx.fillStyle = i % 2 === 0 ? "#ff5ca8" : "#8be6ff";
      ctx.fillRect(boardX + 24, 178 + (i % 2) * 18, 90, 34);
      ctx.fillStyle = "#203049";
      ctx.fillRect(boardX + 18, 212 + (i % 2) * 18, 8, 48);
      ctx.fillRect(boardX + 112, 212 + (i % 2) * 18, 8, 48);
      ctx.fillStyle = "#f4f7fb";
      ctx.fillRect(boardX + 34, 192 + (i % 2) * 18, 48, 6);
      ctx.fillRect(boardX + 34, 202 + (i % 2) * 18, 30, 4);
    }

    for (let i = 0; i < 4; i += 1) {
      const lightX = i * 260 - cameraX * 0.58 + 40;
      const sweep = Math.sin(state.player.stepTimer * 0.9 + i) * 90;
      ctx.fillStyle = "#dff7ff18";
      ctx.beginPath();
      ctx.moveTo(lightX, FLOOR_Y - 4);
      ctx.lineTo(lightX - 20 + sweep, 120);
      ctx.lineTo(lightX + 20 + sweep, 120);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#5a6c85";
      ctx.fillRect(lightX - 4, FLOOR_Y - 56, 8, 52);
    }

    const trainBaseX = 1180 - (cameraX * 0.9 + state.player.stepTimer * 90) % 1480;
    for (let i = 0; i < 3; i += 1) {
      const carX = trainBaseX + i * 118;
      ctx.fillStyle = i === 0 ? "#6a81a5" : "#586d8f";
      ctx.fillRect(carX, 304, 104, 34);
      ctx.fillStyle = "#d8f4ff";
      for (let w = 0; w < 4; w += 1) {
        ctx.fillRect(carX + 12 + w * 22, 314, 12, 7);
      }
      ctx.fillStyle = "#263247";
      ctx.fillRect(carX, 336, 104, 8);
    }

    ctx.fillStyle = "#2b3347";
    ctx.fillRect(0, FLOOR_Y - 12, VIEW_WIDTH, 12);
    ctx.fillStyle = "#3a455f";
    ctx.fillRect(0, FLOOR_Y, VIEW_WIDTH, VIEW_HEIGHT - FLOOR_Y);
    ctx.fillStyle = "#ffd25f";
    for (let i = 0; i < 20; i += 1) {
      ctx.fillRect(i * 52 - (cameraX * 0.7) % 52, FLOOR_Y + 38, 24, 4);
    }
    ctx.fillStyle = "#8be6ff";
    for (let i = 0; i < 24; i += 1) {
      const neonX = (i * 88 - cameraX * 0.42 + state.player.stepTimer * (5 + (i % 3))) % (VIEW_WIDTH + 80);
      const neonY = 118 + (i % 9) * 28;
      ctx.fillRect(neonX - 20, neonY, 10, 2);
    }
    return;
  }

  if (state.stageTheme === "grassland") {
    ctx.fillStyle = "#84d2ff";
    ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

    const sunX = 740 - cameraX * 0.04;
    ctx.fillStyle = "#fff2a8";
    ctx.beginPath();
    ctx.arc(sunX, 84, 34, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#d7f3ff";
    for (let i = 0; i < 7; i += 1) {
      const x = ((i * 230 - cameraX * 0.16) % (VIEW_WIDTH + 260)) - 40;
      ctx.beginPath();
      ctx.arc(x, 96 + (i % 2) * 16, 36, 0, Math.PI * 2);
      ctx.arc(x + 38, 100 + (i % 2) * 16, 28, 0, Math.PI * 2);
      ctx.arc(x - 30, 104 + (i % 2) * 16, 24, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = "#87b96c";
    for (let i = 0; i < 8; i += 1) {
      const hillX = i * 260 - cameraX * 0.2;
      ctx.beginPath();
      ctx.moveTo(hillX - 50, 366);
      ctx.quadraticCurveTo(hillX + 80, 250 - (i % 2) * 20, hillX + 230, 366);
      ctx.lineTo(hillX + 230, 430);
      ctx.lineTo(hillX - 50, 430);
      ctx.fill();
    }

    ctx.fillStyle = "#5c8b3c";
    for (let i = 0; i < 14; i += 1) {
      const trunkX = i * 250 - cameraX * 0.48;
      ctx.fillRect(trunkX + 22, 334, 10, 124);
      ctx.fillStyle = "#82b25d";
      ctx.beginPath();
      ctx.arc(trunkX + 27, 322, 28, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(trunkX + 8, 336, 20, 0, Math.PI * 2);
      ctx.arc(trunkX + 46, 336, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#5c8b3c";
    }

    for (let i = 0; i < 5; i += 1) {
      const millX = i * 420 - cameraX * 0.22 + 60;
      ctx.fillStyle = "#86643b";
      ctx.fillRect(millX + 14, 278, 14, 180);
      ctx.fillStyle = "#d9e8bf";
      ctx.beginPath();
      ctx.moveTo(millX + 20, 292);
      ctx.lineTo(millX + 66 + Math.sin(state.player.stepTimer * 1.1 + i) * 6, 284);
      ctx.lineTo(millX + 24, 304);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(millX + 20, 292);
      ctx.lineTo(millX - 22 - Math.sin(state.player.stepTimer * 1.1 + i) * 6, 300);
      ctx.lineTo(millX + 16, 304);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(millX + 20, 292);
      ctx.lineTo(millX + 28, 248 - Math.sin(state.player.stepTimer * 1.1 + i) * 6);
      ctx.lineTo(millX + 16, 288);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(millX + 20, 292);
      ctx.lineTo(millX + 12, 336 + Math.sin(state.player.stepTimer * 1.1 + i) * 6);
      ctx.lineTo(millX + 24, 296);
      ctx.closePath();
      ctx.fill();
    }

    ctx.fillStyle = "#7fc25c";
    ctx.fillRect(0, FLOOR_Y, VIEW_WIDTH, VIEW_HEIGHT - FLOOR_Y);
    ctx.fillStyle = "#6faa45";
    for (let i = 0; i < 26; i += 1) {
      ctx.fillRect(i * 42 - (cameraX * 0.56) % 42, FLOOR_Y + 22 + (i % 2) * 6, 18, 5);
    }
    ctx.fillStyle = "#b5ec79";
    for (let i = 0; i < 30; i += 1) {
      const gustX = (i * 78 - cameraX * 0.34 + state.player.stepTimer * (6 + (i % 4))) % (VIEW_WIDTH + 60);
      const gustY = 118 + (i % 10) * 28;
      ctx.fillRect(gustX - 20, gustY, 14, 2);
    }
    return;
  }

  if (state.stageTheme === "harbor") {
    ctx.fillStyle = "#7cc9ff";
    ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

    const sunX = 760 - cameraX * 0.04;
    ctx.fillStyle = "#fff0ad";
    ctx.beginPath();
    ctx.arc(sunX, 82, 32, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#c8ecff";
    for (let i = 0; i < 7; i += 1) {
      const x = ((i * 230 - cameraX * 0.16) % (VIEW_WIDTH + 260)) - 40;
      ctx.beginPath();
      ctx.arc(x, 96 + (i % 2) * 14, 34, 0, Math.PI * 2);
      ctx.arc(x + 36, 100 + (i % 2) * 14, 26, 0, Math.PI * 2);
      ctx.arc(x - 28, 104 + (i % 2) * 14, 22, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.fillStyle = "#5f7f93";
    for (let i = 0; i < 8; i += 1) {
      const craneX = i * 250 - cameraX * 0.22;
      ctx.fillRect(craneX + 18, 214, 16, 246);
      ctx.fillRect(craneX + 4, 214, 120, 14);
      ctx.fillRect(craneX + 94, 228, 12, 96);
      ctx.fillRect(craneX + 10, 248, 10, 84);
      const armSwing = Math.sin(state.player.stepTimer * 0.7 + i) * 18;
      ctx.save();
      ctx.translate(craneX + 100, 232);
      ctx.rotate((armSwing - 8) * Math.PI / 180);
      ctx.fillRect(-8, 0, 12, 112);
      ctx.fillRect(-2, 90, 4, 34);
      ctx.restore();
    }

    ctx.fillStyle = "#4c90b1";
    ctx.fillRect(0, 360, VIEW_WIDTH, 100);
    ctx.fillStyle = "#7bd7ff";
    for (let i = 0; i < 18; i += 1) {
      const waveX = i * 64 - (cameraX * 0.48) % 64;
      ctx.fillRect(waveX, 380 + (i % 2) * 10, 34, 3);
      ctx.fillRect(waveX + 16, 408 + (i % 3) * 8, 24, 3);
    }

    const ships = [
      { x: 520, y: 330, width: 170 },
      { x: 1460, y: 322, width: 190 },
      { x: 2400, y: 334, width: 180 }
    ];
    for (const ship of ships) {
      const screenX = ship.x - cameraX * 0.56;
      ctx.fillStyle = "#41596b";
      ctx.fillRect(screenX, ship.y + 26, ship.width, 18);
      ctx.fillRect(screenX + 26, ship.y + 6, 70, 24);
      ctx.fillStyle = "#d2edf7";
      ctx.fillRect(screenX + 40, ship.y + 12, 12, 6);
      ctx.fillRect(screenX + 58, ship.y + 12, 12, 6);
      ctx.fillRect(screenX + 76, ship.y + 12, 12, 6);
    }

    const stacks = [
      { x: 420, y: 356, cols: 2, rows: 2 },
      { x: 1180, y: 344, cols: 3, rows: 2 },
      { x: 2160, y: 350, cols: 2, rows: 3 }
    ];
    for (const stack of stacks) {
      const screenX = stack.x - cameraX * 0.74;
      for (let row = 0; row < stack.rows; row += 1) {
        for (let col = 0; col < stack.cols; col += 1) {
          const cx = screenX + col * 54;
          const cy = stack.y - row * 28;
          ctx.fillStyle = (row + col) % 3 === 0 ? "#d86d4b" : (row + col) % 3 === 1 ? "#4f7fa0" : "#6e9658";
          ctx.fillRect(cx, cy, 50, 24);
          ctx.fillStyle = "#dff7ff44";
          ctx.fillRect(cx + 6, cy + 5, 38, 3);
        }
      }
    }

    ctx.fillStyle = "#85603b";
    ctx.fillRect(0, FLOOR_Y - 10, VIEW_WIDTH, 10);
    ctx.fillStyle = "#9a7144";
    ctx.fillRect(0, FLOOR_Y, VIEW_WIDTH, VIEW_HEIGHT - FLOOR_Y);
    ctx.fillStyle = "#c69a62";
    for (let i = 0; i < 22; i += 1) {
      ctx.fillRect(i * 48 - (cameraX * 0.58) % 48, FLOOR_Y + 22 + (i % 2) * 6, 22, 5);
    }
    return;
  }

  ctx.fillStyle = "#71c0ff";
  ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

  const sunX = 760 - cameraX * 0.05;
  ctx.fillStyle = "#ffe493";
  ctx.beginPath();
  ctx.arc(sunX, 84, 34, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#bce7ff";
  for (let i = 0; i < 7; i += 1) {
    const x = ((i * 220 - cameraX * 0.18) % (VIEW_WIDTH + 260)) - 40;
    ctx.beginPath();
    ctx.arc(x, 90 + (i % 2) * 18, 36, 0, Math.PI * 2);
    ctx.arc(x + 36, 94 + (i % 2) * 18, 28, 0, Math.PI * 2);
    ctx.arc(x - 30, 100 + (i % 2) * 18, 24, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.fillStyle = "#8db2c8";
  for (let i = 0; i < 10; i += 1) {
    const baseX = i * 340 - cameraX * 0.26;
    ctx.fillRect(baseX, 280, 100, 180);
    ctx.fillRect(baseX + 44, 232, 48, 228);
    ctx.fillRect(baseX + 16, 324, 150, 136);
  }

  ctx.fillStyle = "#4f6e56";
  for (let i = 0; i < 12; i += 1) {
    const trunkX = i * 290 - cameraX * 0.5;
    ctx.fillRect(trunkX + 20, 332, 16, 126);
    ctx.fillRect(trunkX, 320, 56, 12);
    ctx.fillRect(trunkX - 10, 308, 74, 10);
  }

  ctx.fillStyle = "#5d8f63";
  for (let i = 0; i < 11; i += 1) {
    const bushX = i * 320 - cameraX * 0.62;
    ctx.fillRect(bushX + 10, 392, 70, 18);
    ctx.fillRect(bushX + 2, 404, 86, 24);
    ctx.fillRect(bushX + 24, 378, 34, 16);
  }

  const interceptProps = [
    { x: 2170, width: 110, height: 18 },
    { x: 2805, width: 100, height: 18 }
  ];
  for (const prop of interceptProps) {
    const screenX = prop.x - cameraX;
    if (screenX + prop.width < -40 || screenX > VIEW_WIDTH + 40) {
      continue;
    }
    ctx.fillStyle = "#866941";
    ctx.fillRect(screenX, FLOOR_Y - prop.height, prop.width, prop.height);
    ctx.fillStyle = "#b69462";
    for (let i = 0; i < 4; i += 1) {
      ctx.fillRect(screenX + 6 + i * 24, FLOOR_Y - prop.height - 8 + (i % 2) * 3, 18, 10);
    }
    ctx.fillStyle = "#5a4430";
    ctx.fillRect(screenX - 12, FLOOR_Y - 12, 10, 12);
    ctx.fillRect(screenX + prop.width + 2, FLOOR_Y - 12, 10, 12);
  }

  const warningSignX = 2485 - cameraX;
  if (warningSignX > -50 && warningSignX < VIEW_WIDTH + 50) {
    ctx.fillStyle = "#5c4631";
    ctx.fillRect(warningSignX, FLOOR_Y - 72, 8, 72);
    ctx.fillStyle = "#d8af42";
    ctx.fillRect(warningSignX - 24, FLOOR_Y - 112, 56, 34);
    ctx.fillStyle = "#4b1d12";
    ctx.font = "bold 14px Arial";
    ctx.fillText("DANGER", warningSignX - 19, FLOOR_Y - 89);
  }

  ctx.fillStyle = "#c9a169";
  ctx.fillRect(0, FLOOR_Y, VIEW_WIDTH, VIEW_HEIGHT - FLOOR_Y);
  ctx.fillStyle = "#b58a53";
  for (let i = 0; i < 24; i += 1) {
    ctx.fillRect(i * 44 - (cameraX * 0.6) % 44, FLOOR_Y + 22 + (i % 2) * 8, 18, 4);
  }
}

function drawPlatforms() {
  for (const platform of platforms) {
    const screenX = platform.x - state.cameraX;
    if (screenX + platform.width < 0 || screenX > VIEW_WIDTH) {
      continue;
    }

    const floorColor = state.stageTheme === "snow" ? "#d8edf8" : state.stageTheme === "desert" ? "#d1a15f" : state.stageTheme === "city" ? "#3e4b62" : state.stageTheme === "grassland" ? "#76b24c" : state.stageTheme === "harbor" ? "#8a6846" : "#7a5b3a";
    const platformColor = state.stageTheme === "snow" ? "#a7d0e8" : state.stageTheme === "desert" ? "#b78648" : state.stageTheme === "city" ? "#55637d" : state.stageTheme === "grassland" ? "#5e9440" : state.stageTheme === "harbor" ? "#70563c" : "#8d6f4b";
    const topColor = state.stageTheme === "snow" ? "#f6fdff" : state.stageTheme === "desert" ? "#f0d193" : state.stageTheme === "city" ? "#9dc9ff" : state.stageTheme === "grassland" ? "#bdf285" : state.stageTheme === "harbor" ? "#cfefff" : "#b8945b";
    const supportColor = state.stageTheme === "snow" ? "#6d8799" : state.stageTheme === "desert" ? "#7a572d" : state.stageTheme === "city" ? "#283247" : state.stageTheme === "grassland" ? "#47712d" : state.stageTheme === "harbor" ? "#384a59" : "#5d4731";
    ctx.fillStyle = platform.y === FLOOR_Y ? floorColor : platformColor;
    ctx.fillRect(screenX, platform.y, platform.width, platform.height);
    ctx.fillStyle = topColor;
    ctx.fillRect(screenX, platform.y, platform.width, 6);

    if (platform.y !== FLOOR_Y) {
      ctx.fillStyle = supportColor;
      ctx.fillRect(screenX + 10, platform.y + 6, 14, platform.height - 6);
      ctx.fillRect(screenX + platform.width - 24, platform.y + 6, 14, platform.height - 6);
    }
  }
}

function drawHostages() {
  for (const hostage of state.hostages) {
    const screenX = hostage.x - state.cameraX;
    if (screenX + hostage.width < 0 || screenX > VIEW_WIDTH) {
      continue;
    }

    ctx.fillStyle = hostage.rescued ? "#ffffff" : "#d8d8d8";
    ctx.fillRect(screenX + 6, hostage.y + 12, 12, 30);
    ctx.fillStyle = "#f0d1b2";
    ctx.fillRect(screenX + 5, hostage.y, 14, 14);
    ctx.fillStyle = hostage.rescued ? "#3ea55d" : "#8f8f8f";
    ctx.fillRect(screenX + 4, hostage.y + 14, 16, 10);

    if (!hostage.rescued) {
      ctx.strokeStyle = "#48352a";
      ctx.lineWidth = 2;
      ctx.strokeRect(screenX - 8, hostage.y - 8, 40, 62);
      ctx.beginPath();
      ctx.moveTo(screenX + 4, hostage.y - 8);
      ctx.lineTo(screenX + 4, hostage.y + 54);
      ctx.moveTo(screenX + 12, hostage.y - 8);
      ctx.lineTo(screenX + 12, hostage.y + 54);
      ctx.moveTo(screenX + 20, hostage.y - 8);
      ctx.lineTo(screenX + 20, hostage.y + 54);
      ctx.stroke();
    }
  }
}

function drawCrates() {
  for (const crate of state.crates) {
    const screenX = crate.x - state.cameraX;
    if (screenX + crate.width < 0 || screenX > VIEW_WIDTH) {
      continue;
    }

    ctx.fillStyle = "#8f6031";
    ctx.fillRect(screenX, crate.y, crate.width, crate.height);
    ctx.fillStyle = "#bf8a51";
    ctx.fillRect(screenX + 2, crate.y + 2, crate.width - 4, 6);
    ctx.fillStyle = "#f4f7fb";
    ctx.font = "bold 16px Arial";
    const label = crate.type === "hmg" ? "H" : crate.type === "shotgun" ? "S" : crate.type === "flame" ? "F" : "G";
    ctx.fillText(label, screenX + 8, crate.y + 18);
  }
}

function drawPickups() {
  for (const pickup of state.pickups) {
    const screenX = pickup.x - state.cameraX;
    ctx.fillStyle = pickup.type === "grenade"
      ? "#ffcc4d"
      : pickup.type === "hmg"
        ? "#ffd25f"
        : pickup.type === "shotgun"
          ? "#d0f0ff"
          : pickup.type === "flame"
            ? "#ff9b45"
            : "#8cffaf";
    ctx.fillRect(screenX, pickup.y, pickup.width, pickup.height);
    ctx.fillStyle = "#1c2533";
    ctx.font = "bold 14px Arial";
    const label = pickup.type === "grenade" ? "G" : pickup.type === "hmg" ? "H" : pickup.type === "shotgun" ? "S" : pickup.type === "flame" ? "F" : "+";
    ctx.fillText(label, screenX + 6, pickup.y + 17);
  }
}

function drawGroundShadow(worldX, width, y, alpha = 0.2) {
  const screenX = worldX - state.cameraX;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = "#000000";
  ctx.beginPath();
  ctx.ellipse(screenX + width / 2, y, Math.max(12, width * 0.42), 8, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawVehicle() {
  const vehicle = state.vehicle;
  if (vehicle.destroyed) {
    return;
  }

  const screenX = vehicle.x - state.cameraX;
  if (screenX + vehicle.width < 0 || screenX > VIEW_WIDTH) {
    return;
  }

  const damaged = vehicle.hp <= Math.ceil(vehicle.maxHp * 0.5);
  const baseColor = state.stageTheme === "snow" ? "#6e95b2" : state.stageTheme === "desert" ? damaged ? "#7a5d3e" : "#8d6a3c" : state.stageTheme === "city" ? damaged ? "#495667" : "#5c6b7f" : state.stageTheme === "grassland" ? damaged ? "#54703d" : "#6c934b" : state.stageTheme === "harbor" ? damaged ? "#42636f" : "#557d8d" : damaged ? "#5f6442" : "#4d8352";
  const midColor = state.stageTheme === "snow" ? "#8fb7d5" : state.stageTheme === "desert" ? damaged ? "#9a7448" : "#b4874a" : state.stageTheme === "city" ? damaged ? "#62758e" : "#7388a3" : state.stageTheme === "grassland" ? damaged ? "#739853" : "#89b55f" : state.stageTheme === "harbor" ? damaged ? "#5a8997" : "#6aa0b3" : damaged ? "#74794d" : "#6aa36c";
  const topColor = state.stageTheme === "snow" ? "#b9d8ee" : state.stageTheme === "desert" ? "#e0bf78" : state.stageTheme === "city" ? "#b7d6ff" : state.stageTheme === "grassland" ? "#d7ff9d" : state.stageTheme === "harbor" ? "#d7f5ff" : damaged ? "#68704b" : "#5e955f";
  const cannonColor = state.stageTheme === "snow" ? "#4c708a" : state.stageTheme === "desert" ? "#704a26" : state.stageTheme === "city" ? "#223042" : state.stageTheme === "grassland" ? "#385b22" : state.stageTheme === "harbor" ? "#234152" : "#2d4c31";
  const cannonShade = state.stageTheme === "snow" ? "#80b3d6" : state.stageTheme === "desert" ? "#d8b57a" : state.stageTheme === "city" ? "#78b7ff" : state.stageTheme === "grassland" ? "#9be06b" : state.stageTheme === "harbor" ? "#89dfff" : "#3e6742";
  drawGroundShadow(vehicle.x, vehicle.width + 18, vehicle.y + vehicle.height + 4, 0.22);
  ctx.fillStyle = baseColor;
  ctx.fillRect(screenX + 6, vehicle.y + 8, vehicle.width - 12, 22);
  ctx.fillStyle = midColor;
  ctx.fillRect(screenX + 2, vehicle.y + 12, vehicle.width - 4, 14);
  ctx.fillStyle = topColor;
  ctx.fillRect(screenX + 12, vehicle.y + 1, 28, 16);
  ctx.fillStyle = "#243526";
  ctx.fillRect(screenX + 19, vehicle.y + 4, 12, 7);
  ctx.fillStyle = "#b9d0b9";
  ctx.fillRect(screenX + 15, vehicle.y + 4, 20, 5);

  ctx.fillStyle = cannonColor;
  ctx.fillRect(screenX + 34, vehicle.y + 4, 28, 7);
  ctx.fillStyle = cannonShade;
  ctx.fillRect(screenX + 34, vehicle.y + 5, 14, 5);

  ctx.fillStyle = "#1c2533";
  ctx.fillRect(screenX + 6, vehicle.y + 25, 20, 9);
  ctx.fillRect(screenX + 48, vehicle.y + 25, 20, 9);
  ctx.fillStyle = "#6f7883";
  ctx.fillRect(screenX + 10, vehicle.y + 27, 12, 4);
  ctx.fillRect(screenX + 52, vehicle.y + 27, 12, 4);

  ctx.fillStyle = "#d6dfd6";
  ctx.fillRect(screenX + 12, vehicle.y + 10, 10, 3);
  ctx.fillRect(screenX + 42, vehicle.y + 17, 14, 3);

  if (damaged) {
    ctx.fillStyle = "#202020";
    ctx.fillRect(screenX + 24, vehicle.y + 6, 10, 4);
    ctx.fillRect(screenX + 47, vehicle.y + 13, 8, 4);
    ctx.fillStyle = "#7d7d7d";
    ctx.fillRect(screenX + 18, vehicle.y - 10, 4, 10);
    ctx.fillRect(screenX + 20, vehicle.y - 14, 6, 4);
  }

  if (vehicle.occupied) {
    ctx.fillStyle = "#f0d1b2";
    ctx.fillRect(screenX + 19, vehicle.y - 6, 12, 10);
    ctx.fillStyle = "#f7b733";
    ctx.fillRect(screenX + 17, vehicle.y + 2, 16, 8);
  }

  if (vehicle.flashTimer > 0) {
    ctx.save();
    ctx.globalAlpha = vehicle.flashTimer / 0.12;
    ctx.fillStyle = "#fff1a6";
    ctx.fillRect(screenX + 60, vehicle.y + 2, 12, 8);
    ctx.fillStyle = "#ff9b45";
    ctx.fillRect(screenX + 66, vehicle.y + 4, 14, 4);
    ctx.restore();
  }

  if (!vehicle.occupied) {
    ctx.fillStyle = "#f4f7fb";
    ctx.font = "bold 14px Arial";
    ctx.fillText("E", screenX + 28, vehicle.y - 6);
  }
}

function drawPlayer() {
  const player = state.player;
  if (state.vehicle.occupied && !state.vehicle.destroyed) {
    return;
  }
  const screenX = player.x - state.cameraX;
  const blink = player.invulnerability > 0 && Math.floor(player.invulnerability * 12) % 2 === 0;
  if (blink) {
    return;
  }

  const heavy = player.weapon === "heavy";
  const shotgun = player.weapon === "shotgun";
  const flame = player.weapon === "flame";
  const stride = player.crouching ? 0 : Math.sin(player.stepTimer * 0.35) * 4;
  const firing = player.shootCooldown > 0.02;
  const gunLength = heavy ? 20 : shotgun ? 22 : flame ? 20 : 15;
  const gunColor = heavy ? "#ffd25f" : shotgun ? "#d0f0ff" : flame ? "#ff9b45" : "#d7dde7";

  // 跳跃姿态参数
  const jumping = !player.onGround && !player.crouching;
  const jumpFrame = jumping ? Math.min(1, Math.max(-1, -player.vy / 400)) : 0;
  const bodyTilt = jumping ? jumpFrame * 0.15 : 0;

  drawGroundShadow(player.x - 2, player.width + 4, player.y + player.height + 3, 0.18);

  ctx.save();
  ctx.translate(screenX + (player.facing > 0 ? 0 : player.width), player.y);
  ctx.scale(player.facing, 1);
  // 应用身体倾斜（跳跃时）
  if (jumping) {
    ctx.translate(20, 24);
    ctx.rotate(bodyTilt);
    ctx.translate(-20, -24);
  }

  // 头带结（飘动）
  ctx.fillStyle = "#c41e3a";
  ctx.fillRect(27, 7, 6, 5);
  ctx.fillRect(30, 9, 8, 4);
  // 黑色皮肤（头部）
  ctx.fillStyle = "#2a1a0f";
  ctx.fillRect(12, 8, 16, 16);
  // 头发（短黑发）
  ctx.fillStyle = "#1a0f08";
  ctx.fillRect(12, 6, 16, 4);
  // 眼睛（白色眼白+黑色瞳孔，朝前看）
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(22, 13, 5, 5);
  ctx.fillStyle = "#0a0a0a";
  ctx.fillRect(24, 14, 3, 3);
  // 头带（红色，系在额头上）
  ctx.fillStyle = "#d41e1e";
  ctx.fillRect(10, 10, 20, 4);
  ctx.fillRect(8, 11, 4, 3);

  // 红色衣服（上装）- 明亮红色
  ctx.fillStyle = "#e53935";
  ctx.fillRect(7, 24, 7, 11);
  ctx.fillStyle = "#f44336";
  ctx.fillRect(11, player.crouching ? 24 : 25, 22, player.crouching ? 13 : 16);
  // 衣服细节/黑色腰带
  ctx.fillStyle = "#212121";
  ctx.fillRect(12, player.crouching ? 29 : 31, 20, 4);
  // 胸前标识（黄色M标志）
  ctx.fillStyle = "#ffeb3b";
  ctx.fillRect(16, player.crouching ? 26 : 27, 8, 4);
  ctx.fillStyle = "#f44336";
  ctx.fillRect(18, player.crouching ? 27 : 28, 4, 2);

  // 黑色皮肤（手臂）- 持枪手
  ctx.fillStyle = "#3d2817";
  ctx.fillRect(11, player.crouching ? 30 : 32, 5, 9);
  // 黑色皮肤（手臂）- 辅助手，随跑动摆动
  const armSwing = player.crouching ? 0 : Math.sin(player.stepTimer * 0.35 + Math.PI) * 3;
  ctx.fillRect(28, (player.crouching ? 28 : 29) + armSwing, 5, 8);

  ctx.fillStyle = "#5d7ea0";
  if (player.crouching) {
    ctx.fillRect(12, 37, 18, 8);
    ctx.fillStyle = "#1d2230";
    ctx.fillRect(11, 44, 9, 8);
    ctx.fillRect(22, 44, 9, 8);
  } else {
    ctx.fillRect(12, 41, 18, 12);
    ctx.fillStyle = "#1d2230";
    ctx.fillRect(12, 52, 8, 11 + stride);
    ctx.fillRect(22, 52, 8, 11 - stride);
  }

  ctx.fillStyle = "#4f5663";
  ctx.fillRect(30, player.crouching ? 28 : 29, gunLength, 7);
  ctx.fillStyle = gunColor;
  ctx.fillRect(35, player.crouching ? 29 : 30, gunLength - 4, 5);
  ctx.fillStyle = "#d9dee7";
  ctx.fillRect(31 + gunLength, player.crouching ? 30 : 31, 4, 3);

  if (firing) {
    ctx.fillStyle = "#fff1a6";
    ctx.fillRect(34 + gunLength, player.crouching ? 27 : 28, 8, 8);
    ctx.fillStyle = "#ff9b45";
    ctx.fillRect(40 + gunLength, player.crouching ? 29 : 30, 8, 4);
  }

  ctx.restore();

  if (player.hurtTimer > 0) {
    ctx.save();
    ctx.globalAlpha = (player.hurtTimer / 0.2) * 0.4;
    ctx.fillStyle = "#fff7d6";
    ctx.fillRect(screenX + 4, player.y + 5, 34, player.crouching ? 48 : 56);
    ctx.restore();
  }
}


function drawEnemy(enemy) {
  const screenX = enemy.x - state.cameraX;
  if (screenX + enemy.width < 0 || screenX > VIEW_WIDTH || enemy.hp <= 0) {
    return;
  }

  if (enemy.type === "mech") {
    drawGroundShadow(enemy.x, enemy.width + 10, enemy.y + enemy.height + 3, 0.22);
    ctx.fillStyle = state.stageTheme === "snow" ? "#6e86a0" : state.stageTheme === "desert" ? "#82674d" : state.stageTheme === "city" ? "#526175" : state.stageTheme === "grassland" ? "#5d7248" : state.stageTheme === "harbor" ? "#4a6c77" : "#5d6875";
    ctx.fillRect(screenX, enemy.y + 18, enemy.width, enemy.height - 18);
    ctx.fillStyle = state.stageTheme === "snow" ? "#9fb8cf" : state.stageTheme === "desert" ? "#b89668" : state.stageTheme === "city" ? "#90a6c0" : state.stageTheme === "grassland" ? "#88a968" : state.stageTheme === "harbor" ? "#7fb4c4" : "#7c8896";
    ctx.fillRect(screenX + 10, enemy.y, enemy.width - 20, 26);
    ctx.fillStyle = "#2d3b4b";
    ctx.fillRect(screenX + enemy.width - 12, enemy.y + 20, 24, 10);
    ctx.fillStyle = "#1c2533";
    ctx.fillRect(screenX + 8, enemy.y + enemy.height - 10, 20, 8);
    ctx.fillRect(screenX + enemy.width - 28, enemy.y + enemy.height - 10, 20, 8);
    ctx.fillStyle = state.stageTheme === "snow" ? "#bff6ff" : state.stageTheme === "desert" ? "#ffe1a1" : state.stageTheme === "city" ? "#b8f7ff" : state.stageTheme === "grassland" ? "#eaffb8" : state.stageTheme === "harbor" ? "#d2fbff" : "#ffb84d";
    ctx.fillRect(screenX + 18, enemy.y + 8, 14, 8);
    ctx.fillRect(screenX + enemy.width - 32, enemy.y + 8, 14, 8);
    if (state.stageTheme === "snow") {
      ctx.fillStyle = "#f4fbff";
      ctx.fillRect(screenX + 12, enemy.y + 4, enemy.width - 24, 5);
    } else if (state.stageTheme === "desert") {
      ctx.fillStyle = "#ecd6a6";
      ctx.fillRect(screenX + 12, enemy.y + 4, enemy.width - 24, 5);
    } else if (state.stageTheme === "city") {
      ctx.fillStyle = "#d8ebff";
      ctx.fillRect(screenX + 12, enemy.y + 4, enemy.width - 24, 5);
    } else if (state.stageTheme === "grassland") {
      ctx.fillStyle = "#eaffbf";
      ctx.fillRect(screenX + 12, enemy.y + 4, enemy.width - 24, 5);
    } else if (state.stageTheme === "harbor") {
      ctx.fillStyle = "#d7f8ff";
      ctx.fillRect(screenX + 12, enemy.y + 4, enemy.width - 24, 5);
    }
  } else if (enemy.type === "glider") {
    drawGroundShadow(enemy.x, enemy.width + 16, enemy.y + enemy.height + 18, 0.12);
    ctx.save();
    ctx.translate(screenX + (enemy.direction > 0 ? 0 : enemy.width), enemy.y);
    ctx.scale(enemy.direction > 0 ? 1 : -1, 1);
    ctx.fillStyle = "#6e5233";
    ctx.fillRect(10, 20, 12, 10);
    ctx.fillStyle = enemy.color;
    ctx.beginPath();
    ctx.moveTo(6, 18);
    ctx.lineTo(26, 12);
    ctx.lineTo(46, 18);
    ctx.lineTo(28, 28);
    ctx.lineTo(12, 28);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#dfecc0";
    ctx.beginPath();
    ctx.moveTo(0, 18);
    ctx.lineTo(24, 4);
    ctx.lineTo(24, 14);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(52, 18);
    ctx.lineTo(28, 4);
    ctx.lineTo(28, 14);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#2f3a29";
    ctx.fillRect(17, 16, 4, 22);
    ctx.fillStyle = "#f1dfcb";
    ctx.fillRect(14, 9, 10, 9);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(20, 11, 3, 3);
    ctx.fillStyle = enemy.bulletColor || "#f5ffd2";
    ctx.fillRect(42, 18, 10, 4);
    ctx.restore();
  } else {
    const stride = enemy.stationary ? 0 : Math.sin((enemy.x + enemy.y) * 0.05) * 3;
    drawGroundShadow(enemy.x, enemy.width, enemy.y + enemy.height + 3, 0.18);
    ctx.save();
    ctx.translate(screenX + (enemy.direction > 0 ? 0 : enemy.width), enemy.y);
    ctx.scale(enemy.direction > 0 ? 1 : -1, 1);

    // 敌人身体 - 使用传入的颜色
    ctx.fillStyle = enemy.color || "#8d3a3a";
    ctx.fillRect(10, 12, 18, 22);
    // 衣服细节
    ctx.fillStyle = state.stageTheme === "snow" ? "#5d7594" : state.stageTheme === "desert" ? "#7a4d24" : state.stageTheme === "city" ? "#425268" : state.stageTheme === "grassland" ? "#53713a" : state.stageTheme === "harbor" ? "#345262" : "#6a2a2a";
    ctx.fillRect(12, 16, 14, 4);
    ctx.fillRect(12, 26, 14, 4);
    // 头部
    ctx.fillStyle = "#f1dfcb";
    ctx.fillRect(11, 4, 16, 12);
    // 头发
    ctx.fillStyle = "#3d2618";
    ctx.fillRect(11, 2, 16, 4);
    if (state.stageTheme === "snow") {
      ctx.fillStyle = "#eef8ff";
      ctx.fillRect(9, 4, 20, 4);
      ctx.fillRect(11, 0, 14, 3);
    } else if (state.stageTheme === "desert") {
      ctx.fillStyle = "#f0d59a";
      ctx.fillRect(9, 5, 20, 4);
    } else if (state.stageTheme === "city") {
      ctx.fillStyle = "#d8ebff";
      ctx.fillRect(9, 4, 20, 4);
      ctx.fillRect(11, 0, 14, 3);
    } else if (state.stageTheme === "grassland") {
      ctx.fillStyle = "#eaffbf";
      ctx.fillRect(9, 4, 20, 4);
    } else if (state.stageTheme === "harbor") {
      ctx.fillStyle = "#d7f8ff";
      ctx.fillRect(9, 4, 20, 4);
      ctx.fillRect(11, 0, 14, 3);
    }
    // 眼睛
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(18, 8, 5, 4);
    ctx.fillStyle = "#000000";
    ctx.fillRect(20, 9, 2, 2);
    ctx.fillStyle = "#2a2a2a";
    ctx.fillRect(20, 13, 3, 3);

    ctx.fillStyle = enemy.color;
    ctx.fillRect(8, 21, 22, 17);
    ctx.fillStyle = state.stageTheme === "snow" ? "#6884a8" : state.stageTheme === "desert" ? "#9b5c2d" : state.stageTheme === "city" ? "#4f637d" : state.stageTheme === "grassland" ? "#698f45" : state.stageTheme === "harbor" ? "#4f89a2" : "#82352f";
    ctx.fillRect(10, 25, 18, 5);
    ctx.fillStyle = "#f1dfcb";
    ctx.fillRect(7, 25, 4, 10);
    ctx.fillRect(28, 24, 4, 9);

    ctx.fillStyle = "#3d4758";
    ctx.fillRect(9, 38, 20, 9);
    ctx.fillStyle = "#1b2230";
    ctx.fillRect(10, 46, 7, 9 + stride);
    ctx.fillRect(21, 46, 7, 9 - stride);

    ctx.fillStyle = state.stageTheme === "snow" ? "#dff7ff" : state.stageTheme === "desert" ? enemy.type === "sniper" ? "#ffe0a4" : "#dfc08b" : state.stageTheme === "city" ? enemy.type === "sniper" ? "#b8f7ff" : "#d7e3f2" : state.stageTheme === "grassland" ? enemy.type === "sniper" ? "#efffb2" : "#dce9c3" : state.stageTheme === "harbor" ? enemy.type === "sniper" ? "#c7fbff" : "#d2e7ef" : enemy.type === "sniper" ? "#b992ff" : "#b3bcc9";
    ctx.fillRect(28, 24, enemy.type === "sniper" ? 18 : 14, 4);
    ctx.fillStyle = "#454f5f";
    ctx.fillRect(31, 22, enemy.type === "sniper" ? 22 : 16, 5);
    ctx.fillStyle = "#d7dde7";
    ctx.fillRect(44, 23, 4, 2);
    ctx.restore();
  }

  if (enemy.hurtTimer > 0) {
    ctx.save();
    ctx.globalAlpha = (enemy.hurtTimer / 0.14) * 0.38;
    ctx.fillStyle = "#fff4cc";
    ctx.fillRect(screenX + 2, enemy.y + 2, enemy.width - 4, enemy.height - 2);
    ctx.restore();
  }

  const hpRatio = enemy.hp / enemy.maxHp;
  ctx.fillStyle = "#00000066";
  ctx.fillRect(screenX, enemy.y - 12, enemy.width, 6);
  ctx.fillStyle = "#69df7d";
  ctx.fillRect(screenX, enemy.y - 12, enemy.width * hpRatio, 6);
}

function drawForegroundDecorations() {
  const cameraX = state.cameraX;

  if (state.stageTheme === "desert") {
    const ambushCovers = [
      { x: 1500, width: 84, height: 68 },
      { x: 2260, width: 72, height: 62 }
    ];
    for (const cover of ambushCovers) {
      const screenX = cover.x - cameraX;
      if (screenX + cover.width < -40 || screenX > VIEW_WIDTH + 40) {
        continue;
      }
      ctx.fillStyle = "#8b6032";
      ctx.fillRect(screenX, FLOOR_Y - cover.height, cover.width, cover.height);
      ctx.fillStyle = "#d1a56b";
      ctx.fillRect(screenX + 8, FLOOR_Y - cover.height + 10, cover.width - 16, 8);
      ctx.fillStyle = "#5e3c20";
      ctx.fillRect(screenX + 18, FLOOR_Y - 18, cover.width - 36, 18);
    }
    return;
  }

  if (state.stageTheme === "grassland") {
    ctx.save();
    ctx.globalAlpha = 0.88;
    for (let i = 0; i < 20; i += 1) {
      const tuftX = i * 56 - (cameraX * 0.86) % 56;
      const height = 28 + (i % 3) * 16;
      ctx.fillStyle = i % 2 === 0 ? "#6aa642" : "#7db952";
      ctx.beginPath();
      ctx.moveTo(tuftX, FLOOR_Y);
      ctx.lineTo(tuftX + 12, FLOOR_Y - height);
      ctx.lineTo(tuftX + 24, FLOOR_Y);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(tuftX + 14, FLOOR_Y);
      ctx.lineTo(tuftX + 28, FLOOR_Y - height - 8);
      ctx.lineTo(tuftX + 38, FLOOR_Y);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    return;
  }

  if (state.stageTheme === "harbor") {
    for (let i = 0; i < 8; i += 1) {
      const splashX = i * 138 - (cameraX * 0.92 + state.player.stepTimer * 16) % 138;
      const baseY = 370 + (i % 2) * 10;
      ctx.fillStyle = "#d8fbff88";
      ctx.beginPath();
      ctx.arc(splashX + 20, baseY, 10, Math.PI, 0);
      ctx.fill();
      ctx.fillRect(splashX + 10, baseY - 8, 4, 10);
      ctx.fillRect(splashX + 18, baseY - 12, 4, 14);
      ctx.fillRect(splashX + 26, baseY - 8, 4, 10);
    }
  }
}

function drawTurret(turret) {
  const screenX = turret.x - state.cameraX;
  if (screenX + turret.width < 0 || screenX > VIEW_WIDTH || turret.hp <= 0) {
    return;
  }

  drawGroundShadow(turret.x - 2, turret.width + 8, turret.y + turret.height + 4, 0.22);
  ctx.fillStyle = state.stageTheme === "snow" ? "#9ab0c6" : state.stageTheme === "desert" ? "#ab8351" : state.stageTheme === "city" ? "#5d708c" : state.stageTheme === "grassland" ? "#6a8d49" : state.stageTheme === "harbor" ? "#5a8091" : "#7c6540";
  ctx.fillRect(screenX - 10, turret.y + turret.height - 12, turret.width + 20, 12);
  ctx.fillStyle = state.stageTheme === "snow" ? "#bfd3e6" : state.stageTheme === "desert" ? "#d3b177" : state.stageTheme === "city" ? "#88a6cc" : state.stageTheme === "grassland" ? "#a8cb6f" : state.stageTheme === "harbor" ? "#8cc0d3" : "#8f764c";
  for (let i = 0; i < 4; i += 1) {
    ctx.fillRect(screenX - 8 + i * 18, turret.y + turret.height - 20, 16, 10);
  }

  ctx.fillStyle = state.stageTheme === "snow" ? "#7f93ab" : state.stageTheme === "desert" ? "#80654a" : state.stageTheme === "city" ? "#4f617a" : state.stageTheme === "grassland" ? "#566c3b" : state.stageTheme === "harbor" ? "#4a6374" : "#6c727b";
  ctx.fillRect(screenX + 2, turret.y + 18, turret.width - 4, turret.height - 18);
  ctx.fillStyle = state.stageTheme === "snow" ? "#d5e6f4" : state.stageTheme === "desert" ? "#e3c88f" : state.stageTheme === "city" ? "#d8ebff" : state.stageTheme === "grassland" ? "#efffb2" : state.stageTheme === "harbor" ? "#d7f8ff" : "#90979f";
  ctx.fillRect(screenX + 10, turret.y + 2, turret.width - 20, 24);
  ctx.fillStyle = "#2f3642";
  ctx.fillRect(screenX + (turret.direction > 0 ? turret.width - 2 : -20), turret.y + 14, 24, 10);
  ctx.fillStyle = "#c8d0d6";
  ctx.fillRect(screenX + 18, turret.y + 8, 10, 5);
  ctx.fillRect(screenX + 31, turret.y + 8, 10, 5);
  if (state.stageTheme === "snow") {
    ctx.fillStyle = "#f5fbff";
    ctx.fillRect(screenX + 8, turret.y - 2, turret.width - 16, 4);
  } else if (state.stageTheme === "desert") {
    ctx.fillStyle = "#f1dba9";
    ctx.fillRect(screenX + 8, turret.y - 2, turret.width - 16, 4);
  } else if (state.stageTheme === "city") {
    ctx.fillStyle = "#d7edff";
    ctx.fillRect(screenX + 8, turret.y - 2, turret.width - 16, 4);
  } else if (state.stageTheme === "grassland") {
    ctx.fillStyle = "#ecffb9";
    ctx.fillRect(screenX + 8, turret.y - 2, turret.width - 16, 4);
  } else if (state.stageTheme === "harbor") {
    ctx.fillStyle = "#d7f8ff";
    ctx.fillRect(screenX + 8, turret.y - 2, turret.width - 16, 4);
  }
  ctx.fillStyle = "#1c2533";
  ctx.fillRect(screenX + 10, turret.y + turret.height - 8, turret.width - 20, 8);

  if (turret.flashTimer > 0) {
    ctx.save();
    ctx.globalAlpha = turret.flashTimer / 0.1;
    ctx.fillStyle = "#fff1a6";
    ctx.fillRect(screenX + (turret.direction > 0 ? turret.width + 10 : -16), turret.y + 12, 10, 14);
    ctx.fillStyle = "#ff9b45";
    ctx.fillRect(screenX + (turret.direction > 0 ? turret.width + 18 : -24), turret.y + 16, 12, 6);
    ctx.restore();
  }

  if (turret.hurtTimer > 0) {
    ctx.save();
    ctx.globalAlpha = (turret.hurtTimer / 0.14) * 0.34;
    ctx.fillStyle = "#fff4cc";
    ctx.fillRect(screenX + 2, turret.y + 2, turret.width - 4, turret.height - 2);
    ctx.restore();
  }

  const hpRatio = turret.hp / turret.maxHp;
  ctx.fillStyle = "#00000066";
  ctx.fillRect(screenX, turret.y - 12, turret.width, 6);
  ctx.fillStyle = "#69df7d";
  ctx.fillRect(screenX, turret.y - 12, turret.width * hpRatio, 6);
}

function drawBoss() {
  const boss = state.boss;
  if (boss.hp <= 0) {
    return;
  }

  const screenX = boss.x - state.cameraX;
  if (screenX + boss.width < 0 || screenX > VIEW_WIDTH) {
    return;
  }

  const pulse = (Math.sin(boss.pulseTimer * 4.5) + 1) * 0.5;

  drawGroundShadow(boss.x, boss.width + 20, boss.y + boss.height + 6, 0.26);
  ctx.fillStyle = boss.bodyColor;
  ctx.fillRect(screenX, boss.y + 26, boss.width, boss.height - 26);
  ctx.fillStyle = boss.topColor;
  ctx.fillRect(screenX + 12, boss.y, boss.width - 24, 40);
  ctx.fillStyle = boss.detailColor;
  ctx.fillRect(screenX + 20, boss.y + 10, boss.width - 40, 14);
  ctx.fillStyle = boss.gunColor;
  ctx.fillRect(screenX - 36, boss.y + 50, 44, 20);
  ctx.fillRect(screenX + boss.width - 8, boss.y + 58, 32, 14);
  ctx.fillStyle = "#d4d8df";
  ctx.fillRect(screenX + 24, boss.y + 38, 26, 24);
  ctx.fillRect(screenX + 84, boss.y + 38, 26, 24);
  ctx.fillStyle = boss.eyeColor;
  ctx.fillRect(screenX + 31, boss.y + 45, 8, 8);
  ctx.fillRect(screenX + 92, boss.y + 45, 8, 8);
  ctx.fillStyle = "#3b444f";
  ctx.fillRect(screenX + 28, boss.y + 86, 78, 28);
  ctx.fillStyle = "#1d2430";
  ctx.fillRect(screenX + 16, boss.y + 104, 106, 12);
  ctx.fillStyle = "#bdc8d6";
  ctx.fillRect(screenX + 34, boss.y + 46, 10, 10);
  ctx.fillRect(screenX + 90, boss.y + 46, 10, 10);

  ctx.save();
  ctx.globalAlpha = 0.08 + pulse * 0.14;
  ctx.fillStyle = boss.glowColor;
  ctx.fillRect(screenX - 10, boss.y - 10, boss.width + 20, boss.height + 20);
  ctx.restore();

  if (boss.flashTimer > 0) {
    ctx.save();
    ctx.globalAlpha = boss.flashTimer / 0.14;
    ctx.fillStyle = "#fff1a6";
    ctx.fillRect(screenX - 52, boss.y + 44, 18, 26);
    ctx.fillStyle = boss.gunColor;
    ctx.fillRect(screenX - 34, boss.y + 50, 26, 12);
    ctx.fillStyle = "#ffd6a3";
    ctx.fillRect(screenX + boss.width + 6, boss.y + 54, 14, 20);
    ctx.restore();
  }

  if (boss.hurtTimer > 0) {
    ctx.save();
    ctx.globalAlpha = (boss.hurtTimer / 0.2) * 0.28;
    ctx.fillStyle = "#fff4cc";
    ctx.fillRect(screenX + 6, boss.y + 4, boss.width - 12, boss.height - 6);
    ctx.restore();
  }

  ctx.fillStyle = "#00000088";
  ctx.fillRect(648, 24, 250, 18);
  ctx.fillStyle = "#ff6d5f";
  ctx.fillRect(648, 24, 250 * (boss.hp / boss.maxHp), 18);
  ctx.fillStyle = "#fff0a8";
  ctx.fillRect(648, 24, 250 * (boss.hp / boss.maxHp), 5);
  ctx.fillStyle = "#f4f7fb";
  ctx.font = "bold 14px Arial";
  ctx.fillText(`BOSS ${boss.name}`, 648, 18);
  ctx.fillStyle = "#ffe08a";
  ctx.font = "bold 12px Arial";
  ctx.fillText(`PHASE ${boss.phase}`, 850, 18);
}

function drawProjectiles() {
  for (const bullet of state.bullets) {
    if (bullet.trailColor) {
      ctx.fillStyle = bullet.trailColor;
      ctx.globalAlpha = 0.34;
      const trailWidth = Math.max(8, bullet.width * 1.8);
      const trailX = bullet.x - state.cameraX - (bullet.vx >= 0 ? trailWidth : -bullet.width);
      ctx.fillRect(trailX, bullet.y + 1, trailWidth, Math.max(2, bullet.height - 2));
      ctx.globalAlpha = 1;
    }
    ctx.fillStyle = bullet.color;
    ctx.fillRect(bullet.x - state.cameraX, bullet.y, bullet.width, bullet.height);
    if (bullet.width >= 14) {
      ctx.fillStyle = "#fff7ce";
      ctx.fillRect(bullet.x - state.cameraX + 3, bullet.y + 1, Math.max(4, bullet.width - 7), Math.max(2, bullet.height - 2));
    }
  }

  for (const grenade of state.grenades) {
    const screenX = grenade.x - state.cameraX;
    ctx.fillStyle = "#4b5968";
    ctx.fillRect(screenX, grenade.y, grenade.width, grenade.height);
    ctx.fillStyle = "#ffcc4d";
    ctx.fillRect(screenX + 3, grenade.y + 3, 6, 6);
  }

  for (const bullet of state.enemyBullets) {
    if (bullet.trailColor) {
      ctx.fillStyle = bullet.trailColor;
      ctx.globalAlpha = bullet.width >= 14 ? 0.36 : 0.24;
      const trailWidth = Math.max(10, bullet.width * 2);
      const trailX = bullet.x - state.cameraX - (bullet.vx >= 0 ? trailWidth : -bullet.width);
      ctx.fillRect(trailX, bullet.y + 2, trailWidth, Math.max(3, bullet.height - 4));
      ctx.globalAlpha = 1;
    }
    ctx.fillStyle = bullet.color;
    ctx.fillRect(bullet.x - state.cameraX, bullet.y, bullet.width, bullet.height);
    if (bullet.width >= 14) {
      ctx.fillStyle = "#ffe08a";
      ctx.fillRect(bullet.x - state.cameraX + 3, bullet.y + 2, Math.max(4, bullet.width - 6), Math.max(2, bullet.height - 4));
    }
  }

  for (const hazard of state.hazards) {
    const screenX = hazard.x - state.cameraX;
    if (hazard.type === "iceWall") {
      ctx.fillStyle = "#fffbff44";
      ctx.fillRect(screenX - 3, FLOOR_Y - 8, hazard.width + 6, 8);
      if (hazard.riseTimer > 0) {
        ctx.fillStyle = "#a8ecff";
        ctx.globalAlpha = 0.45;
        ctx.fillRect(screenX, FLOOR_Y - 8, hazard.width, 6);
        ctx.globalAlpha = 1;
      } else {
        const topY = FLOOR_Y - hazard.activeHeight;
        ctx.fillStyle = "#e7fbff";
        ctx.fillRect(screenX, topY, hazard.width, hazard.activeHeight);
        ctx.fillStyle = "#9fe7ff";
        ctx.fillRect(screenX + 4, topY + 8, hazard.width - 8, Math.max(6, hazard.activeHeight - 16));
        ctx.fillStyle = "#ffffffaa";
        ctx.fillRect(screenX + 2, topY + 4, 5, Math.max(4, hazard.activeHeight - 14));
      }
      continue;
    }
    if (hazard.type === "sandPillar") {
      ctx.fillStyle = "#ffe7bd66";
      ctx.fillRect(screenX - 4, FLOOR_Y - 8, hazard.width + 8, 8);
      if (hazard.riseTimer > 0) {
        ctx.fillStyle = "#e5b670";
        ctx.globalAlpha = 0.45;
        ctx.fillRect(screenX, FLOOR_Y - 8, hazard.width, 6);
        ctx.globalAlpha = 1;
      } else {
        const topY = FLOOR_Y - hazard.activeHeight;
        ctx.fillStyle = "#d4a05f";
        ctx.fillRect(screenX, topY, hazard.width, hazard.activeHeight);
        ctx.fillStyle = "#f2d29a";
        ctx.fillRect(screenX + 5, topY + 8, hazard.width - 10, Math.max(6, hazard.activeHeight - 18));
        ctx.fillStyle = "#8b6032";
        ctx.fillRect(screenX + 8, topY + 10, 6, Math.max(10, hazard.activeHeight - 22));
      }
      continue;
    }
    if (hazard.type === "laserFence") {
      ctx.fillStyle = "#d5fbff55";
      ctx.fillRect(screenX - 3, FLOOR_Y - 8, hazard.width + 6, 8);
      if (hazard.riseTimer > 0) {
        ctx.fillStyle = "#7ce8ff";
        ctx.globalAlpha = 0.5;
        ctx.fillRect(screenX, FLOOR_Y - 8, hazard.width, 6);
        ctx.globalAlpha = 1;
      } else {
        const topY = FLOOR_Y - hazard.activeHeight;
        ctx.fillStyle = "#6cdfff";
        ctx.fillRect(screenX, topY, hazard.width, hazard.activeHeight);
        ctx.fillStyle = "#d8fbff";
        ctx.fillRect(screenX + 6, topY + 8, hazard.width - 12, Math.max(8, hazard.activeHeight - 16));
        ctx.fillStyle = "#ffffffcc";
        ctx.fillRect(screenX + 2, topY + 4, 4, Math.max(10, hazard.activeHeight - 10));
        ctx.fillRect(screenX + hazard.width - 6, topY + 4, 4, Math.max(10, hazard.activeHeight - 10));
      }
      continue;
    }
    if (hazard.type === "thornWall") {
      ctx.fillStyle = "#efffb255";
      ctx.fillRect(screenX - 4, FLOOR_Y - 8, hazard.width + 8, 8);
      if (hazard.riseTimer > 0) {
        ctx.fillStyle = "#b2dc61";
        ctx.globalAlpha = 0.48;
        ctx.fillRect(screenX, FLOOR_Y - 8, hazard.width, 6);
        ctx.globalAlpha = 1;
      } else {
        const topY = FLOOR_Y - hazard.activeHeight;
        ctx.fillStyle = "#68993f";
        ctx.fillRect(screenX, topY, hazard.width, hazard.activeHeight);
        ctx.fillStyle = "#d9ff97";
        for (let i = 0; i < 3; i += 1) {
          ctx.beginPath();
          ctx.moveTo(screenX + 4 + i * 10, topY + hazard.activeHeight);
          ctx.lineTo(screenX + 10 + i * 10, topY + hazard.activeHeight - 16 - (i % 2) * 6);
          ctx.lineTo(screenX + 16 + i * 10, topY + hazard.activeHeight);
          ctx.closePath();
          ctx.fill();
        }
      }
      continue;
    }
    if (hazard.type === "steamColumn") {
      ctx.fillStyle = "#d6fbff55";
      ctx.fillRect(screenX - 4, FLOOR_Y - 8, hazard.width + 8, 8);
      if (hazard.riseTimer > 0) {
        ctx.fillStyle = "#a8f1ff";
        ctx.globalAlpha = 0.5;
        ctx.fillRect(screenX, FLOOR_Y - 8, hazard.width, 6);
        ctx.globalAlpha = 1;
      } else {
        const topY = FLOOR_Y - hazard.activeHeight;
        ctx.fillStyle = "#7ce7ff";
        ctx.fillRect(screenX + 8, topY, hazard.width - 16, hazard.activeHeight);
        ctx.fillStyle = "#dffcff";
        ctx.fillRect(screenX + 2, topY + 10, hazard.width - 4, Math.max(8, hazard.activeHeight - 18));
      }
      continue;
    }
    if (hazard.type === "sandShard") {
      ctx.fillStyle = "#f7d89a";
      ctx.beginPath();
      ctx.moveTo(screenX + hazard.width / 2, hazard.y);
      ctx.lineTo(screenX + hazard.width, hazard.y + hazard.height - 6);
      ctx.lineTo(screenX + hazard.width / 2, hazard.y + hazard.height);
      ctx.lineTo(screenX, hazard.y + hazard.height - 6);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#b27a3d";
      ctx.fillRect(screenX + hazard.width / 2 - 1, hazard.y + 5, 2, hazard.height - 10);
      continue;
    }
    if (hazard.type === "missile") {
      ctx.fillStyle = "#d8ebff";
      ctx.fillRect(screenX + 4, hazard.y, 8, hazard.height - 10);
      ctx.fillStyle = "#7ce8ff";
      ctx.beginPath();
      ctx.moveTo(screenX + hazard.width / 2, hazard.y);
      ctx.lineTo(screenX + hazard.width, hazard.y + 10);
      ctx.lineTo(screenX, hazard.y + 10);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#ff9b45";
      ctx.fillRect(screenX + 5, hazard.y + hazard.height - 10, 6, 10);
      ctx.fillStyle = "#ffe5a1";
      ctx.fillRect(screenX + 6, hazard.y + hazard.height - 6, 4, 6);
      continue;
    }
    if (hazard.type === "windBlade") {
      ctx.fillStyle = "#eaffb8";
      ctx.beginPath();
      ctx.ellipse(screenX + hazard.width / 2, hazard.y + hazard.height / 2, hazard.width / 2, hazard.height / 3, Math.PI / 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#9fd15a";
      ctx.fillRect(screenX + 4, hazard.y + 8, hazard.width - 8, 3);
      continue;
    }
    if (hazard.type === "depthCharge") {
      ctx.fillStyle = "#486d7a";
      ctx.fillRect(screenX + 3, hazard.y + 4, hazard.width - 6, hazard.height - 8);
      ctx.fillStyle = "#d7f8ff";
      ctx.beginPath();
      ctx.arc(screenX + hazard.width / 2, hazard.y + 7, 7, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = "#8ce7ff";
      ctx.fillRect(screenX + 6, hazard.y + 10, hazard.width - 12, 4);
      continue;
    }
    ctx.fillStyle = "#e7fbff";
    ctx.beginPath();
    ctx.moveTo(screenX + hazard.width / 2, hazard.y);
    ctx.lineTo(screenX + hazard.width, hazard.y + hazard.height - 8);
    ctx.lineTo(screenX + hazard.width / 2, hazard.y + hazard.height);
    ctx.lineTo(screenX, hazard.y + hazard.height - 8);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#9fe7ff";
    ctx.fillRect(screenX + hazard.width / 2 - 1, hazard.y + 6, 2, hazard.height - 12);
  }
}

function drawEffects() {
  for (const effect of state.effects) {
    ctx.globalAlpha = Math.max(0, effect.ttl / effect.maxTtl);
    ctx.fillStyle = effect.color;
    ctx.beginPath();
    ctx.arc(effect.x - state.cameraX, effect.y, effect.radius, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawSnowMarks() {
  if (state.stageTheme !== "snow") {
    return;
  }
  for (const mark of state.snowMarks) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, mark.ttl / mark.maxTtl) * 0.45;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(mark.x - state.cameraX, mark.y, mark.width, 4);
    ctx.fillRect(mark.x + 3 - state.cameraX, mark.y - 3, Math.max(6, mark.width - 6), 2);
    ctx.restore();
  }
}

function drawFragments() {
  for (const fragment of state.fragments) {
    ctx.globalAlpha = Math.max(0, fragment.ttl / fragment.maxTtl);
    ctx.fillStyle = fragment.color;
    ctx.fillRect(fragment.x - state.cameraX, fragment.y, fragment.width, fragment.height);
  }
  ctx.globalAlpha = 1;
}

function drawFloatingTexts() {
  for (const text of state.floatingTexts) {
    ctx.globalAlpha = Math.max(0, text.ttl / text.maxTtl);
    ctx.fillStyle = text.color;
    ctx.font = `bold ${text.size}px Arial`;
    ctx.fillText(text.text, text.x - state.cameraX, text.y);
  }
  ctx.globalAlpha = 1;
}

function drawHud() {
  const player = state.player;
  const vehicle = state.vehicle;
  const activeTurrets = state.turrets.filter((turret) => turret.hp > 0).length;
  const weaponCode =
    player.weapon === "heavy"
      ? "H"
      : player.weapon === "shotgun"
        ? "S"
        : player.weapon === "flame"
          ? "F"
          : "N";
  const ammoLabel = player.weapon === "normal" ? "--" : `${player.weaponAmmo}`;
  const weaponName =
    player.weapon === "heavy"
      ? "HEAVY"
      : player.weapon === "shotgun"
        ? "SHOT"
        : player.weapon === "flame"
          ? "FLAME"
          : "NORMAL";
  const terrainLabel = getTerrainLabel(state.stageTheme);

  ctx.fillStyle = "#132033d9";
  ctx.fillRect(18, 18, 370, 92);
  ctx.fillStyle = "#f4f7fb";
  ctx.font = "bold 22px Arial";
  ctx.fillText("P1 MARCO", 34, 44);
  ctx.font = "16px Arial";
  ctx.fillText(`生命 ${player.hp}`, 34, 72);
  ctx.fillText(`手雷 ${player.grenades}`, 122, 72);
  ctx.fillText(`武器 ${weaponCode}`, 206, 72);
  ctx.fillText(`得分 ${state.score}`, 272, 72);
  ctx.fillText(`进度 ${Math.floor((player.x / (WORLD_WIDTH - 120)) * 100)}%`, 34, 96);
  ctx.fillText(`${weaponName} ${ammoLabel}`, 122, 96);
  ctx.fillText(vehicle.occupied && !vehicle.destroyed ? `载具 ${vehicle.hp}/${vehicle.maxHp}` : "载具待命", 236, 96);
  ctx.fillText(`地形 ${terrainLabel}`, 236, 72);

  for (let i = 0; i < player.hp; i += 1) {
    ctx.fillStyle = "#ff6d5f";
    ctx.fillRect(96 + i * 18, 57, 12, 12);
  }

  for (let i = 0; i < Math.min(player.grenades, 6); i += 1) {
    ctx.fillStyle = "#ffcc4d";
    ctx.fillRect(176 + i * 16, 57, 10, 12);
  }

  if (!state.bossAwake) {
    ctx.fillStyle = "#132033cc";
    ctx.fillRect(562, 20, 350, 42);
    ctx.fillStyle = "#f4f7fb";
    ctx.font = "17px Arial";
    const bannerText =
      activeTurrets > 0 && player.x > 1960
        ? `拦截炮台剩余 ${activeTurrets} 座，清掉后继续推进`
        : state.stageTheme === "snow"
          ? `${state.stageTip}，注意冰面惯性与冰锥雨`
          : state.stageTheme === "desert"
            ? `${state.stageTip}，注意沙暴碎片与遗迹石柱`
            : state.stageTheme === "city"
              ? `${state.stageTip}，注意导弹雨与能量栅栏`
              : state.stageTheme === "grassland"
                ? `${state.stageTip}，注意风刃雨与荆棘墙`
              : state.stageTheme === "harbor"
                ? `${state.stageTip}，注意深水炸弹与蒸汽柱`
          : state.stageTip;
    ctx.fillText(bannerText, 576, 47);
  }
}

function drawStageBanner() {
  if (state.stageBannerTimer <= 0 && state.warningTimer <= 0 && state.interceptBannerTimer <= 0 && state.eventNoticeTimer <= 0) {
    return;
  }

  ctx.textAlign = "center";
  if (state.stageBannerTimer > 0) {
    ctx.globalAlpha = Math.min(1, state.stageBannerTimer / 0.8);
    ctx.fillStyle = "#08111fcc";
    ctx.fillRect(0, 0, VIEW_WIDTH, 110);
    ctx.fillStyle = "#ffd25f";
    ctx.font = "bold 34px Arial";
    ctx.fillText(state.missionLabel, VIEW_WIDTH / 2, 46);
    ctx.fillStyle = "#f4f7fb";
    ctx.font = "24px Arial";
    ctx.fillText(state.missionSubtitle, VIEW_WIDTH / 2, 82);
  }

  if (state.warningTimer > 0) {
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = "#6b1212";
    ctx.fillRect(0, 210, VIEW_WIDTH, 72);
    ctx.fillStyle = "#b71c1c";
    ctx.fillRect(0, 206, VIEW_WIDTH, 6);
    ctx.fillRect(0, 276, VIEW_WIDTH, 6);
    ctx.fillStyle = "#ffe08a";
    ctx.font = "bold 38px Arial";
    ctx.fillText("WARNING !!", VIEW_WIDTH / 2, 258);
  }

  if (state.interceptBannerTimer > 0) {
    ctx.globalAlpha = 0.92;
    ctx.fillStyle = "#53210d";
    ctx.fillRect(0, 136, VIEW_WIDTH, 54);
    ctx.fillStyle = "#ffd25f";
    ctx.font = "bold 28px Arial";
    ctx.fillText("INTERCEPT POINT", VIEW_WIDTH / 2, 172);
  }

  if (state.eventNoticeTimer > 0) {
    ctx.globalAlpha = Math.min(0.94, state.eventNoticeTimer / 0.4);
    ctx.fillStyle = "#10253acc";
    ctx.fillRect(0, 132, VIEW_WIDTH, 46);
    ctx.fillStyle = state.eventNoticeColor;
    ctx.font = "bold 24px Arial";
    ctx.fillText(state.eventNoticeText, VIEW_WIDTH / 2, 162);
  }
  ctx.globalAlpha = 1;
  ctx.textAlign = "start";
}

function drawStageClearMessage() {
  if (!state.stageClear) {
    return;
  }

  ctx.fillStyle = "#08111fcc";
  ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
  ctx.fillStyle = "#f4f7fb";
  ctx.textAlign = "center";
  ctx.font = "bold 42px Arial";
  ctx.fillText(`${state.missionLabel} CLEAR`, VIEW_WIDTH / 2, 200);
  ctx.font = "24px Arial";
  ctx.fillText(`正在转入 ${state.nextMissionLabel}：${state.nextMissionSubtitle}`, VIEW_WIDTH / 2, 252);
  ctx.fillText(`当前得分 ${state.score}`, VIEW_WIDTH / 2, 296);
  ctx.font = "18px Arial";
  ctx.fillText(getStageLoadingText(state.nextStageTheme), VIEW_WIDTH / 2, 336);
  ctx.textAlign = "start";
}

function drawEndMessage() {
  if (!state.victory && !state.gameOver) {
    return;
  }

  ctx.fillStyle = "#08111fcc";
  ctx.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

  ctx.fillStyle = "#f4f7fb";
  ctx.textAlign = "center";
  ctx.font = "bold 44px Arial";
  ctx.fillText(state.victory ? "ALL MISSIONS COMPLETE" : "MISSION FAILED", VIEW_WIDTH / 2, 200);
  ctx.font = "24px Arial";
  ctx.fillText(state.victory ? "丛林、冰原、沙海、都市、草原与海港战区全部突破，六段闭环已完成。" : "本次突击失败，点击重开或按 R 重新挑战当前关卡。", VIEW_WIDTH / 2, 256);
  ctx.fillText(`最终得分 ${state.score}`, VIEW_WIDTH / 2, 300);
  ctx.font = "18px Arial";
  ctx.fillText(state.victory ? "你已经打通海港主题第六关。" : "调整武器与路线后再冲一次。", VIEW_WIDTH / 2, 338);
  ctx.textAlign = "start";
}

function render() {
  ctx.clearRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
  drawBackground();

  const shakeX = state.shakeTime > 0 ? (Math.random() - 0.5) * state.shakePower : 0;
  const shakeY = state.shakeTime > 0 ? (Math.random() - 0.5) * state.shakePower : 0;

  ctx.save();
  ctx.translate(shakeX, shakeY);
  drawPlatforms();
  drawSnowMarks();
  drawHostages();
  drawCrates();
  drawPickups();
  drawVehicle();

  for (const enemy of state.enemies) {
    drawEnemy(enemy);
  }
  for (const turret of state.turrets) {
    drawTurret(turret);
  }

  drawBoss();
  drawProjectiles();
  drawPlayer();
  drawFragments();
  drawEffects();
  drawFloatingTexts();
  drawForegroundDecorations();
  ctx.restore();

  drawHud();
  drawStageBanner();
  drawStageClearMessage();
  drawEndMessage();
}

function frame(timestamp) {
  if (!lastTime) {
    lastTime = timestamp;
  }
  const dt = Math.min(0.033, (timestamp - lastTime) / 1000);
  lastTime = timestamp;

  update(dt);
  render();
  requestAnimationFrame(frame);
}

resetGame();
window.__metalSlugLite = {
  resetGame,
  getState: () => state,
  fire: firePlayerBullet,
  grenade: throwGrenade,
  setStage: (index) => {
    resetGame(index);
  },
  mountVehicle: () => {
    state.player.x = state.vehicle.x;
    state.player.y = FLOOR_Y - state.player.height;
    state.player.vehicleCooldown = 0;
  },
  warpPlayer: (x) => {
    state.player.x = clamp(x, 0, WORLD_WIDTH - state.player.width);
  }
};
requestAnimationFrame(frame);
